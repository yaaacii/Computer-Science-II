/**
 * @brief  CS-202 Project 9 NodeQueue class .cpp file
 * @Author Cicelia Siu
 *
 * This file is the .cpp file to implement the NodeQueue class for Project 9
 */

#include "NodeQueue.h"


std::ostream & operator <<(std::ostream& os, const NodeQueue& nodeQueue){
    nodeQueue.serialize(os);
    return os;
}

NodeQueue::NodeQueue(){
    m_front = NULL;
    m_back = NULL;
}

NodeQueue::NodeQueue(size_t size, const DataType & value){
    m_front = NULL;
    m_back = NULL;
    for (size_t i = 0; i < size; i++){
        push(value);
    }
}

NodeQueue::NodeQueue(const NodeQueue & other){
    m_front = NULL;
    m_back = NULL;

    Node * curr = other.m_front;
    for (size_t i = 0; i < other.size(); i++, curr = curr->m_next){
        push(curr->data());
    }
}

NodeQueue::~NodeQueue(){
    Node * curr = m_front;
    Node * next = nullptr;

    while (curr != NULL){
        next = curr->m_next;
        delete curr;
        curr = next;
    }
}

NodeQueue & NodeQueue::operator= (const NodeQueue& rhs){
    clear();
    m_front = NULL;
    m_back = NULL;

    Node * curr = rhs.m_front;
    for (size_t i = 0; i < rhs.size(); i++, curr = curr->m_next){
        push(curr->data());
    }
    return *this;
}

DataType & NodeQueue::front(){
    return m_front->data();
}

const DataType & NodeQueue::front() const{
    return m_front->data();
}

DataType & NodeQueue::back(){
    return m_back->data();
}

const DataType & NodeQueue::back() const{
    return m_back->data();
}

void NodeQueue::push(const DataType & value){
	Node * newN = new Node(value);
	if (empty()){
		m_front = newN;
		m_back = newN;
	} else {
	m_back->m_next = newN;
	m_back = newN;
    }
}

void NodeQueue::pop(){
    if (m_front){
		Node * ptr = m_front;
		m_front = m_front->m_next;
		delete ptr;
	}
}

size_t NodeQueue::size() const{
    Node * curr = m_front;
    size_t count = 0;

    while (curr != NULL){
        curr = curr->m_next;
        count++;
    }
    return count;
}

bool NodeQueue::empty() const{
    if (size() == 0){
        return 1;
    } else {
        return 0;
    }
}

bool NodeQueue::full() const{
    return false;
}

void NodeQueue::clear(){
    Node * curr = m_front;
    Node * deleteNode = nullptr;

    while (curr != NULL){
        deleteNode = curr;
        curr = curr->m_next;
        delete deleteNode;

    }
    m_front = NULL;
    m_back = NULL;
}

void NodeQueue::serialize(std::ostream & os)const{
    Node * curr = m_front;
    for (size_t i = 0; curr != NULL; curr = curr->m_next, i++){
		os << i << ". " << curr->data() << std::endl;
	}
}
