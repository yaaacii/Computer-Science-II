/**
 * @brief  CS-202 Project 9 ArrayQueue class .cpp file
 * @Author Cicelia Siu
 *
 * This file is the .cpp file to implement the ArrayQueue class for Project 9
 */
#include "ArrayQueue.h"

std::ostream & operator<<(std::ostream&os, const ArrayQueue&arrayQueue){
    arrayQueue.serialize(os);
    return os;
} 

ArrayQueue::ArrayQueue(){
    m_front = 0;
    m_back = 0;
    m_size = 0;
}

ArrayQueue::ArrayQueue(size_t count, const DataType & value){
    m_front = 0;
    m_back = 0;
    m_size = 0; //will increate during push

    for (int i = 0; i < count; i++){
        push (value);
    }
}

ArrayQueue::ArrayQueue(const ArrayQueue& other){
    m_front = other.m_front;
    m_back = other.m_back;
    m_size = other.m_size;                          //diff

    for (size_t i = 0; i < other.m_size; i++){
        m_array[i] = other.m_array[i];              //different
    }
}

ArrayQueue::~ArrayQueue(){
   //no allocation so nothing happens
}

ArrayQueue & ArrayQueue::operator=(const ArrayQueue & rhs){
    m_front = rhs.m_front;
    m_back = rhs.m_back;
    m_size = rhs.m_size;                          //diff

    for (size_t i = 0; i < rhs.m_size; i++){
        m_array[i] = rhs.m_array[i];              //different
    }
    return *this;
}

DataType & ArrayQueue::front(){
    return m_array[m_front];
}

const DataType & ArrayQueue::front() const{
    return m_array[m_front];
}

DataType & ArrayQueue::back(){
    return m_array[m_back];
}

const DataType & ArrayQueue::back() const{
    return m_array[m_back];
}

void ArrayQueue::push(const DataType & value){
    if (!full()){
        if (empty()){
            m_array[m_front] = value;                   //different
            m_array[m_back] = value;
            m_size++;
        } else {
            m_back = (m_back + 1) % ARRAY_CAPACITY;
            m_array[m_back] = value;
            ++m_size;
        }
    } else {
        std::cout << "The array is full" <<std::endl;
    }
}

void ArrayQueue::pop(){
    if (!empty()){
        m_front =(m_front+1) % ARRAY_CAPACITY;
        --m_size;
    }
}

size_t ArrayQueue::size() const{
    return m_size;
}

bool ArrayQueue::empty() const{
    if (m_size == 0){
        return 1;
    } else {
        return 0;
    }
}

bool ArrayQueue::full() const{
    if (m_size == ARRAY_CAPACITY){
        return 1;
    } else {
        return 0;
    }
}

void ArrayQueue::clear(){
    m_size = 0;
    m_front = 0;
    m_back = 0;
}

void ArrayQueue::serialize(std::ostream & os)const{
    for (int i = 0; i < m_size; i++){
        os << i << ". " << m_array[i + m_front]<< std::endl;
    }

}

