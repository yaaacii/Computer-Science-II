/**
 * @brief  CS-202 Project 9  main .cpp file
 * @Author Cicelia Siu
 *
 * This file is the main .cpp file to test all functions for Project 9
 */

#include "ArrayQueue.h"
#include "NodeQueue.h"

int main (){
    DataType value1(1, 1);
	DataType value2(2, 2);
	DataType value3(3, 3);
	DataType value4(4, 4);
	DataType value5(5, 5);

    std::cout << std::endl << "-----------------Testing Array Based List------------------" << std::endl;

    std::cout << std::endl << "Testing Default, Parameterized, and Copy Ctor" << std::endl;

    ArrayQueue queue1;
    ArrayQueue queue2(10, value2);
    ArrayQueue queue3(queue2);

    std::cout << std::endl << "Printing Array Queue 1 w/ nothing: " << std::endl << queue1 << std::endl;
    std::cout << std::endl << "Printing Array Queue 2 w/ {2,2}: " << std::endl << queue2 << std::endl;
    std::cout << std::endl << "Printing Array Queue 3 w/ {2,2}: " << std::endl << queue3 << std::endl;

    std::cout << std::endl << "Testing Assignment Operator : Array Queue 1 = Array Queue 2" << std::endl;
    queue1 = queue2;
    std::cout << std::endl << "Printing Array Queue 1 w/ {2,2}: " << std::endl << queue1 << std::endl;
    std::cout << std::endl << "Printing Array Queue 2 w/ {2,2}: " << std::endl << queue2 << std::endl;
    std::cout << std::endl << "Printing Array Queue 3 w/ {2,2}: " << std::endl << queue3 << std::endl;

    std::cout << std::endl << "Testing in Array Queue 1: front() = value1 and back() = value 3" << std::endl;
    queue1.front() = value1;
    queue1.back() = value3;
    std::cout << std::endl << "Printing Array Queue 1 w/ {2,2}: " << std::endl << queue1 << std::endl;

    std::cout << std::endl << "Testing in Array Queue 1: push({2,2}) and pop()" << std::endl;
    queue1.push(value2);
    queue1.pop();
    std::cout << std::endl << "Printing Array Queue 1: " << std::endl << queue1 << std::endl;

    std::cout << std::endl << "Testing in clear() for all Array Queues" << std::endl;
    queue1.clear();
    queue2.clear();
    queue3.clear();
    std::cout << std::endl << "Printing Array Queue 1: " << std::endl << queue1 << std::endl;
    std::cout << std::endl << "Printing Array Queue 2: " << std::endl << queue2 << std::endl;
    std::cout << std::endl << "Printing Array Queue 3: " << std::endl << queue3 << std::endl;

    std::cout << std::endl << "-----------------End of Array Based List Tests------------------" << std::endl;




    std::cout << std::endl << "-----------------Testing Array Based List------------------" << std::endl;

    std::cout << std::endl << "Testing Default, Parameterized, and Copy Ctor" << std::endl;
    NodeQueue nqueue1;
    NodeQueue nqueue2(10, value2);
    NodeQueue nqueue3(nqueue2);
    std::cout << std::endl << "Printing Node Queue 1 w/ nothing: " << std::endl << nqueue1 << std::endl;
    std::cout << std::endl << "Printing Node Queue 2 w/ {2,2}: " << std::endl << nqueue2 << std::endl;
    std::cout << std::endl << "Printing Node Queue 3 w/ {2,2}: " << std::endl << nqueue3 << std::endl;

    std::cout << std::endl << "Testing Assignment Operator : Node Queue 1 = Node Queue 2" << std::endl;
    nqueue1 = nqueue2;
    std::cout << std::endl << "Printing Node Queue 1 w/ {2,2}: " << std::endl << nqueue1 << std::endl;
    std::cout << std::endl << "Printing Node Queue 2 w/ {2,2}: " << std::endl << nqueue2 << std::endl;
    std::cout << std::endl << "Printing Node Queue 3 w/ {2,2}: " << std::endl << nqueue3 << std::endl;

    std::cout << std::endl << "Testing in Node Queue 1: front() = value1 and back() = value 3" << std::endl;
    nqueue1.front() = value1;
    nqueue1.back() = value3;
    std::cout << std::endl << "Printing Node Queue 1: " << std::endl << nqueue1 << std::endl;

    std::cout << std::endl << "Testing in Node Queue 1: push({2,2}) and pop()" << std::endl;
    nqueue1.push(value2);
    nqueue1.pop();
    std::cout << std::endl << "Printing Node Queue 1: " << std::endl << nqueue1 << std::endl;

    std::cout << std::endl << "Testing in clear() for all Node Queues" << std::endl;
    nqueue1.clear();
    nqueue2.clear();
    nqueue3.clear();
    std::cout << std::endl << "Printing Node Queue 1 w/ {2,2}: " << std::endl << nqueue1 << std::endl;
    std::cout << std::endl << "Printing Node Queue 2 w/ {2,2}: " << std::endl << nqueue2 << std::endl;
    std::cout << std::endl << "Printing Node Queue 3 w/ {2,2}: " << std::endl << nqueue3 << std::endl;

    std::cout << std::endl << "-----------------End of Node Based List Tests------------------" << std::endl;

}
