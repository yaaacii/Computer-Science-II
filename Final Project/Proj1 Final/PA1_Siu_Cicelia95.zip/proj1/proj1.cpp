/*
* @Student: Siu, Cicelia
* @Date: Jan 25, 2020
* @Project: 1. Sorting Names from a file
*/
#include <iostream>
#include <fstream>
#define MAXLEN 9
#define NUMOFNAMES 10

//Prototypes

/**Copying a cstring from an array and pasting into another array
* @param destination for pasting the cstring
* @param source for copying the cstring
* @pre source should have cstrings as an array, destination should also be an array
* @post copies cstring from source and pastes into destination
*/
void myStringCopy(char destination [], const char source []);

/**Finding the length of a string
 * @param str cstring
 * @pre The str is a string to find how many letters in it
 * @post finds the length of the given string
 * @returns the length
 */
int myStringLength (const char str []);

/**Compares strings
 * @param str1 first string to compare
 * @param str2 second string to compare
 * @pre str1 and str2 should be character arrays that are initailized
 * @post finds which string is alphabetically lower or higher from ASCII
 * @returns 0 if matched, -1 if str1 is lower on the ASCII table than str2, 1 if str2 is lower on the ASCII table than 1
 */
int myStringCompare(const char str1 [], const char str2 []);

/**Open file and read names into a 2D array
 * @param input file name
 * @param 2D array of names that will be changed later
 * @param 2D array of names in the original order that will not be changed
 * @pre file should be exisiting with names that are less than 8 letters,
 * @post names from file should be in both 2D array with the same order originally
 */
void readNames(char inputFile[], char namesArray[][MAXLEN], char original[][MAXLEN]);

/**Print 2D array of names into the console
 * @param namesArray 2D array of names
 * @param orgIndex index of name from original order
 * @pre initalized 2D array of names no longer than 8 charaters and the original order attached to the name
 * @post prints to the console the index from the original order and the name
 */
void printNamesToTerminal(char namesArray[][MAXLEN], int orgIndex[]);

/**Sorts names alphabetically
 * @param namesArray 2D array of names to be sorted
 * @param indexes indexes of the names in original order
 * @pre initalized 2D array of names and array of indexes to be resorted
 * @post 2D array should be sorted aphabetically with the index of its orginal order 
 */
void sortNamesAlphabetic (char namesArray [][MAXLEN], int indexes []);

/**Sort names by their length
 * @param nameArray 2D array of names to be sorted
 * @param indexes indexes of the names in original order
 * @pre initalized 2D array of names and array of indexes to be resorted
 * @post 2D array should be sorted by length with its index of the original order
 */
void sortNamesByLength(char namesArray[][MAXLEN], int indexes[]);

/**Print names from 2D array into the File
 * @param output file in which the names will be written in
 * @param namesArray is the arrays of the sorted list
 * @param original is the array of the original list
 * @param orgIndex is the indexes of the names in its original order
 * @pre initalized 2D arrays of the sorted list and original list and array of indexes with name of the outputfile
 * @post finds or makes output file and writes in the file original list and sorted list with their original index
 */
void printNamesToFile(char outputFile[], char namesArray[][MAXLEN], char original [][MAXLEN], int orgIndex[]);



int main(){
	// Ask user for input and output file names
	char inputfile[100];
	char outputfile[100];
	std::cout << "Enter the input file name" << std::endl;
	std::cin >> inputfile;
	std::cout << "Enter the output file name" << std::endl;
	std:: cin >> outputfile;

	//read names from inputfile and put into 2D array
	char arrayOnames[NUMOFNAMES][MAXLEN];
	char originalNames[NUMOFNAMES][MAXLEN];
	int originalIndexes[NUMOFNAMES]= {0,1,2,3,4,5,6,7,8,9};
	readNames(inputfile, arrayOnames, originalNames);
    
	//print names to terminal (unsorted)
	std::cout << "Unsorted Data (Original Input Order and Name)\n==============================================" << std::endl;
	printNamesToTerminal(arrayOnames, originalIndexes);

	//sort names alphabetically
	sortNamesAlphabetic(arrayOnames,originalIndexes);
	std::cout << "Alphabetically Sorted Data (Original Input Order and Name)\n==============================================" << std::endl;
	printNamesToTerminal(arrayOnames, originalIndexes);

	//sort names length wise
	sortNamesByLength(arrayOnames, originalIndexes);
	std::cout << "Sorted-by-Length -and- Alphabetically Data (Original Input Order and Name)\n==============================================" << std::endl;
	printNamesToTerminal(arrayOnames, originalIndexes);

	//print original list and sorted list to file
	printNamesToFile(outputfile, arrayOnames, originalNames, originalIndexes);
	return 0;
}

//Function Declaration

//copies c string from the source string until null into the destination 
void myStringCopy(char destination [], const char source[]){
	int index = 0;
	for (index = 0; source [index]!= '\0'; index++){
		destination[index] = source[index];
	}
	destination[index] = '\0'; //add null to complete c-string
}

// find the length of a string until the null and return the length
int myStringLength (const char str []){
	int stringLength = 0;
	for (stringLength = 0; str [stringLength] != '\0'; stringLength++){
	}
	return stringLength;
}

//compares two strings to see if they match
int myStringCompare(const char str1 [], const char str2 []){
	int index = 0;
	int matchValue = 0;
	for (index =0; str1[index]!= '\0' || str2[index] != '\0'; index++ ){
		if (str1[index] > str2[index]){
			matchValue = 1;
			return matchValue;
		}
		else if (str1[index] < str2[index]){
			matchValue = -1;
			return matchValue;
		}
		else if (str1[index] == str2[index]){
			matchValue = 0;
		}
	}
	return matchValue;
}

//open file and copy string into 2D array
void readNames(char inputFile[], char namesArray[][MAXLEN], char original[][MAXLEN]){
	std::ifstream inputStream;
	inputStream.open(inputFile);
	//check if files can be open
	if (!inputStream){
		std::cerr << "File does not exist" << std:: endl;
		return;
	}
	int i = 0;
	while (inputStream.getline(original[i], NUMOFNAMES)){
		myStringCopy(namesArray[i], original[i]);
		++i;
	}
	inputStream.close();
}

//print names to terminal from 2D array
void printNamesToTerminal(char namesArray[][MAXLEN], int orgIndex[]){
	for (int row = 0; row < NUMOFNAMES; row++){
		std::cout << orgIndex[row] << " " << namesArray[row] << std::endl;
	}
	std:: cout << std::endl;
}

//sorts names by bubble sort
void sortNamesAlphabetic (char namesArray [][MAXLEN], int indexes []){
	char temp[MAXLEN];
	int tempInd;
	for (int round = 0; round < NUMOFNAMES-1; round++){
		for (int row = 0; row < NUMOFNAMES-1; row++){
			if (myStringCompare(namesArray[row], namesArray[row+1]) > 0){
				myStringCopy(temp,namesArray[row+1]);
				tempInd = indexes[row+1];
				myStringCopy(namesArray[row+1], namesArray[row]);
				indexes[row+1]= indexes[row];
				myStringCopy(namesArray[row], temp);
				indexes[row] = tempInd;
			}
		}   
	}
}

//sort names and original indexes by length
void sortNamesByLength(char namesArray[][MAXLEN], int indexes[]){
	char temp[MAXLEN];
	int tempInd;
	for (int round = 0; round < NUMOFNAMES-1; round++){
		for (int row = 0; row < NUMOFNAMES-1; row++){
			if (myStringLength(namesArray[row]) > myStringLength(namesArray[row+1])){
				myStringCopy(temp,namesArray[row+1]);
				tempInd = indexes[row+1];
				myStringCopy(namesArray[row+1], namesArray[row]);
				indexes[row+1]= indexes[row];
				myStringCopy(namesArray[row], temp);
				indexes[row] = tempInd;
			}
		}
	}
}

void printNamesToFile(char outputFile[], char namesArray[][MAXLEN], char original [][MAXLEN], int orgIndex[]){
	std::ofstream outputStream;
	outputStream.open(outputFile);
	outputStream << "Unsorted Data (Original Input Order and Name)\n==============================================" << std::endl;
	for (int row = 0; row <= NUMOFNAMES-1; row++){
		outputStream << row << " " << original[row] << std::endl;
	}
	outputStream << std::endl;
	outputStream << "Sorted-by-Length -and- Alphabetically Data (Original Input Order and Name)\n==============================================" << std::endl;
	for (int row = 0; row <= NUMOFNAMES-1; row++){
		outputStream << orgIndex[row]<< " "<< namesArray[row] << std::endl;
	}
}
