/**                                                                             
 *  @Student: Siu, Cicelia                                                      
 *  @Date: March 3, 2020
 *  @Class: CS 202                                                  
 *  @Project: 5
 *  @Derived Class                                                                
 */

#include "Car.h"

Car:: Car(){
    SetThrottle(0); //set throttle to 0
    std:: cout << "Car: Default-ctor"<< std::endl;
}

Car::Car(float *lla) : Vehicle (lla){
	SetThrottle(0);
    std:: cout << "Car: Parameterized-ctor"<< std::endl;
}

Car::Car(const Car & copy): Vehicle(copy){
    SetLLA (copy.m_lla); //copy lla
	SetThrottle(copy.m_throttle);
    std:: cout << "Car: Copy-ctor"<< std::endl;
}

Car:: ~Car(){
    std:: cout << "Car: Dtor"<< std::endl;
}

Car & Car::operator= (const Car & rhs){
    if (this != &rhs){
        SetLLA(rhs.m_lla);
		SetThrottle (rhs.m_throttle);
    }
	std::cout << "Car: Assignment"<< std::endl;
    return *this;
}


int Car::GetThrottle() const{
    return m_throttle;
}


void Car::SetThrottle(const int throttle){
    m_throttle = throttle;
}

void Car::Serialize (std::ostream & os) const{
	os<< "Car: Throttle: "<< GetThrottle() <<" @ [" <<m_lla[0]<< ", "<<m_lla[1]<< ", " << m_lla[2]<< "]"<< std::endl;
}


void Car::Drive(int throttle){
    SetThrottle(throttle);
}

void Car::Move(const float *LLA){
	Drive(75);
    SetLLA(LLA);
    std:: cout<< "Car: DRIVE to destination, with a throttle of "<<m_throttle <<std::endl;
    
}

