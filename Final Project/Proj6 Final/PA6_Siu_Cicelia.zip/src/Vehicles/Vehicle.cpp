/**                                                                             
 *  @Student: Siu, Cicelia                                                      
 *  @Date: March 3, 2020
 *  @Class: CS 202                                                  
 *  @Project: 5
 *  @Base Class                                                               
 */



#include "Vehicle.h"


Vehicle::Vehicle(){ //default constructor
    std:: cout << "Vehicle: Default-ctor"<< std::endl;
}

Vehicle::Vehicle( float * lla){ //parameterized
    SetLLA(lla);
    std:: cout << "Vehicle: Parameterized-ctor"<< std::endl;
}

Vehicle::Vehicle(const Vehicle & copy){
    SetLLA(copy.m_lla);
    std:: cout << "Vehicle: Copy-ctor"<< std::endl;
}

Vehicle::~Vehicle (){
    std:: cout << "Vehicle: Dtor"<< std::endl;
}

Vehicle & Vehicle::operator = (const Vehicle & rhs){
    SetLLA(rhs.m_lla);
    std:: cout << "Vehicle: Assignment" << std::endl;
    return *this;
}

std::ostream & operator<< (std::ostream & output, const Vehicle & vehicle){
    vehicle.Serialize(output);
    return output;
}

float Vehicle::GetLLA(int index) const{
    return m_lla[index];
}


void Vehicle::SetLLA(const float *LLA){
    for (int i = 0; i<3 ; i++){
        m_lla[i]= *LLA;
        LLA++; 
    }
}


// void Vehicle::move(const float *LLA){
//     setLLA(LLA);
//     std:: cout << "Vehicle "<< ": CAN'T MOVE- I DON'T KNOW HOW"<< std::endl;
// }

void Vehicle::Serialize (std::ostream & os) const{
    os<< "Vehicle @ [" <<m_lla[0]<< ", "<<m_lla[1]<< ", " << m_lla[2]<< "]"<< std::endl;
}
