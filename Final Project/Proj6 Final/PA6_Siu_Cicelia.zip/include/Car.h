/**                                                                             
 *  @Student: Siu, Cicelia                                                      
 *  @Date: March 3, 2020
 *  @Class: CS 202                                                  
 *  @Project: 5
 *  @Header File for Derived Class                                                               
 */

#ifndef CAR_H_
#define CAR_H_
#include "Vehicle.h"

 class Car : public Vehicle {
     public:
        Car();
        Car(float *lla);
        Car(const Car & copy);
        virtual ~Car();

        Car & operator= (const Car & rhs); 

        int GetThrottle() const;
        void SetThrottle(const int throttle);

        void Drive (int throttle);
        virtual void Move(const float *LLA);

        virtual void Serialize (std::ostream & os) const;


     private:
        int m_throttle;
 };


#endif
