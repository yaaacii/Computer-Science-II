/**                                                                             
 *  @Student: Siu, Cicelia                                                      
 *  @Date: March 3, 2020
 *  @Class: CS 202                                                  
 *  @Project: 5
 *  @Header File for Base Class                                                               
 */

#ifndef VEHICLE_H_
#define VEHICLE_H_
#include <iostream>
#include <fstream>
#include <cstring>



class Vehicle {
    public:
        Vehicle(); //default 
        Vehicle(float * lla);//parameterized
        Vehicle (const Vehicle & copy); //copy constructor
        virtual ~Vehicle (); //destuctor

        Vehicle & operator= (const Vehicle & rhs);
        friend std::ostream & operator<< (std::ostream & output, const Vehicle & vehicle);

        //getter
        float GetLLA(int index) const;
        //setters
        void SetLLA(const float *LLA);

        virtual void Move (const float *LLA) = 0;


    protected: 
        float m_lla [3]; //Latitude, Longitude, Altitude

    private:
        virtual void Serialize (std::ostream & os) const;
};

#endif
