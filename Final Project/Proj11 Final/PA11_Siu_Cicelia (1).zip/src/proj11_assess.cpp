/* Author: Cicelia Siu
* Project 11: proj11_assess.cpp file
* used to time Vector Recursion functions
*/


#include <iostream>
#include <fstream>
#include "../include/VectorRecursion.hpp"

#include <numeric>
#include <chrono>
 
volatile int sink;
int main(){
double sortavg100 = 0;
double sortavg1000 = 0;
double sortavg10000 = 0;
double searchavg100 = 0;
double searchavg1000 = 0;
double searchavg10000 = 0;
for( int trial = 1; trial < 11; trial++){
	std::cout <<std::endl << "Trial: " << trial << std::endl;
    for (size_t size = 100; size <= 10000; size *= 10) {
        // record start time
        std::chrono::time_point<std::chrono::system_clock> t1 = std::chrono::system_clock::now();
        // do some work
        std::vector<int> vec;
        for (size_t i = 0; i < size; i++){
            int value = rand() % size;
            vec.push_back(value);
        }
        vector_research(vec, 212 ,0, vec.size());
        // record end time
        std::chrono::time_point<std::chrono::system_clock> t2 = std::chrono::system_clock::now();
        std::chrono::duration<double> different = t2-t1;
        std::cout << "Time to fill and research a vector of " 
                  << size << " ints : " << different.count() << " s\n";
	if (size == 100){
		searchavg100 += different.count();
	} else if (size == 1000){
		searchavg1000 += different.count();
	} else if (size == 10000){
		searchavg10000 += different.count();
	}
	vec.clear();
    }
    

    for (size_t size = 100; size <= 10000; size *= 10) {
        //size_t size= 10000;
        // record start time
        std::chrono::time_point<std::chrono::system_clock> t1 = std::chrono::system_clock::now();
        // do some work
        std::vector<int> v;
        for (size_t i = 0; i < size; i++){
            int value = rand() % size;
            v.push_back(value);
        }
        vector_resort(v, 0, v.size()); // make sure it's a side effect
        // record end time
        std::chrono::time_point<std::chrono::system_clock> t2 = std::chrono::system_clock::now();
        std::chrono::duration<double> diff = t2-t1;
        std::cout << "Time to fill and resort a vector of " 
                  << size << " ints : " << diff.count() << " s\n";
	if (size == 100){
		sortavg100 += diff.count();
	} else if (size == 1000){
		sortavg1000 += diff.count();
	} else if (size == 10000){
		sortavg10000 += diff.count();
	}
	v.clear();
    }
    std::cout << std::endl;
    
    std::cout << "Average time to fill and sort 100: "<< sortavg100/10 << "s" <<std::endl;
    std::cout << "Average time to fill and sort 1000: "<< sortavg1000/10 << "s" <<std::endl;
    std::cout << "Average time to fill and sort 10000: "<< sortavg10000/10 << "s" <<std::endl;
    std::cout << "Average time to fill and search 100: "<< searchavg100/10 << "s" <<std::endl;
    std::cout << "Average time to fill and search 1000: "<< searchavg1000/10 << "s" <<std::endl;
    std::cout << "Average time to fill and search 10000: "<< searchavg10000/10 << "s" <<std::endl;
	
}
}
