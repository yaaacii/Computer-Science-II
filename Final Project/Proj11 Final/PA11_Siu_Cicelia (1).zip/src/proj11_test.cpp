/* Author: Cicelia Siu
* Project 11: proj11_assess.cpp file
* used to time Vector Recursion functions
*/

#include <iostream>
#include <fstream>
#include "../include/VectorRecursion.hpp"

const int MAXSIZE = 100;
int main(){

    std::cout << "-----Starting Tests-----" << std::endl;

    std::vector<int> vecInt;

    std::cout << "-----File Input-----" << std::endl;
	std::cout << "Please enter full path to the file: " << std::endl;
	std::string path;
	std::getline(std::cin, path);
    std::ifstream file(path);
	if (!file){
		std::cout<< "Error in finding file" <<std::endl;
	}
	std::cout << std:: endl;
    for (int i=0; i < MAXSIZE; i++){
        int value;
        file >> value;
        vecInt.push_back(value);
    }


    std::cout << "-----Sorting-----" << std::endl;
    vector_resort(vecInt, 0, vecInt.size());
    bool success = 1;
    for (size_t i = 0; i < vecInt.size(); ++i) {
        std::cout << vecInt[i] << std::endl;
        // if (vecInt[i] > vecInt[i+1]){
        //     success = 0;
        // }
    }
    std::cout << "Sorting Success: " << std::boolalpha << success << std::endl;

    std::cout << "-----Research-----" << std::endl;
    bool success1 = 0;
    bool success2 = 0;
    bool success3 = 0;

    int result1 = vector_research (vecInt, 203, 0, MAXSIZE);
    std::cout << "int 203 at : " << result1 << std::endl;
    if (vecInt[result1] == 202){
        success1 = 1;
    }
    std::cout << "Success: " << std::boolalpha << success1 << std::endl;

    int result2 = vector_research (vecInt, 213, 0, MAXSIZE);
    std::cout << "not in vecInt 213: " << result2 << std::endl;
    if (vecInt[result2] == 213){
        success2 = 1;
    }
    std::cout << "Success: " << std::boolalpha << success2 << std::endl;
    
    int result3 = vector_research (vecInt, 500, 0, MAXSIZE);
    std::cout << " outside the range 500: " << result3 << std::endl;
    if (vecInt[result3] == 500){
        success1 = 1;
    }
    std::cout << "Success: " << std::boolalpha << success3 << std::endl;

    std::cout << "-----End of Tests-----" << std::endl;


    
    



}
