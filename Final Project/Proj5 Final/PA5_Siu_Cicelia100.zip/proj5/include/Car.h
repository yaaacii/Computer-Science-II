/**                                                                             
 *  @Student: Siu, Cicelia                                                      
 *  @Date: March 3, 2020
 *  @Class: CS 202                                                  
 *  @Project: 5
 *  @Header File for Derived Class                                                               
 */

#ifndef CAR_H_
#define CAR_H_
#include "Vehicle.h"

 class Car : public Vehicle {
     public:
        Car();
        Car(char * plate, int vin, float *lla);
        Car(const Car & copy);
        ~Car(); //not done

        Car & operator= (const Car & rhs); 

        char *getPlates ();
        int getThrottle();

        void setPlates (const char *plates);
        void setThrottle(const int throttle);

        void drive (int throttle);

        void move(const float *LLA); //how to make sure it the vehicle has moved

        friend std::ostream & operator<< (std::ostream & output, Car & car);



     private:
        char m_plates[256];
        int m_throttle;
 };


#endif
