/**                                                                             
 *  @Student: Siu, Cicelia                                                      
 *  @Date: March 3, 2020
 *  @Class: CS 202                                                  
 *  @Project: 5
 *  @Header File for Base Class                                                               
 */

#ifndef VEHICLE_H_
#define VEHICLE_H_
#include <iostream>
#include <fstream>
#include <cstring>



class Vehicle {
    public:
        Vehicle(); //default 
        Vehicle(int vin, float * lla);//parameterized
        Vehicle (const Vehicle & copy); //copy constructor
        ~Vehicle (); //destuctor

        Vehicle & operator= (const Vehicle & rhs);
        friend std::ostream & operator<< (std::ostream & output, const Vehicle & LLA);

        //getter
        float getLLA(int index) const;
        int getVIN() const; //is this a const fucnction?
        //setters
        void setLLA(const float *LLA);
        void setVIN (const int vin); //how would i do this one?

        void move( const float *LLA); //how to make sure it the vehicle has moved

        static int getIdgen ();

        bool vinCheck(int vin);


    protected: 
        float m_lla [3]; //Latitude, Longitude, Altitude
        const int m_vin; //no vehicle can have the same vin

    private:
        static int s_idgen; //use this to make sure no vehicle has the same vin

};

#endif
