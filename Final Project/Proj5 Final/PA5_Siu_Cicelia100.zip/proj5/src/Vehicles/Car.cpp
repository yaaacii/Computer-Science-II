/**                                                                             
 *  @Student: Siu, Cicelia                                                      
 *  @Date: March 3, 2020
 *  @Class: CS 202                                                  
 *  @Project: 5
 *  @Derived Class                                                                
 */

#include "Car.h"

Car:: Car(){
    setThrottle(0); //set throttle to 0
    std:: cout << "Car #" << m_vin << ": Default-ctor"<< std::endl;
}

Car:: Car(char * plate, int vin, float *lla ): Vehicle (vin, lla) {
    //put name in
    setPlates(plate);
	setThrottle(0);
    std:: cout << "Car #" << m_vin << ": Parameterized-ctor"<< std::endl;
}

Car::Car(const Car & copy): Vehicle(copy){
    setLLA (copy.m_lla); //copy lla
    strcpy(m_plates, copy.m_plates); //copy plates
	setThrottle(copy.m_throttle);
    std:: cout << "Car #" << m_vin << ": Copy-ctor"<< std::endl;
}

Car:: ~Car(){
    std:: cout << "Car #" << m_vin << ": Dtor"<< std::endl;
}

Car & Car::operator= (const Car & rhs){
    std::cout << "Car #" << rhs.m_vin << ": Assignment"<< std::endl;
    if (this != &rhs){
        setLLA(rhs.m_lla);
        setPlates(rhs.m_plates);
    }
    return *this;
}

char * Car::getPlates(){
    return m_plates;
}

int Car::getThrottle(){
    return m_throttle;
}

void Car::setPlates(const char *plates){
    strcpy(m_plates, plates);
}

void Car::setThrottle(const int throttle){
    m_throttle = throttle;
}

void Car::drive(int throttle){
    setThrottle(throttle);
}

void Car::move(const float *LLA){
	drive(75);
    setLLA(LLA);
    std:: cout<< "Car #" << m_vin << ": DRIVE to destination, with a throttle of "<<m_throttle <<std::endl;
    
}
std::ostream & operator<< (std::ostream & output, Car & car){
    output<< "Car #" << car.m_vin << " Plates: "<< car.m_plates << ", Throttle:  "<< car.m_throttle << " @ [" << car.getLLA(0) << ", " << car.getLLA(1) << ", " << car.getLLA(2)<< "]" << std::endl;
    return output;
}
