/**                                                                             
 *  @Student: Siu, Cicelia                                                      
 *  @Date: March 3, 2020
 *  @Class: CS 202                                                  
 *  @Project: 5
 *  @Base Class                                                               
 */



#include "Vehicle.h"

int Vehicle::s_idgen = 99;

Vehicle::Vehicle(): m_vin(s_idgen++){ //default constructor
    std:: cout << "Vehicle #" << m_vin << ": Default-ctor"<< std::endl;
}

Vehicle::Vehicle(int vin, float * lla): m_vin (vinCheck(vin) ?  vin : s_idgen++){ //parameterized
    for (int i =0 ; i < 3 ; i++){
        m_lla[i] = *lla;
        lla++;
    }
    std:: cout << "Vehicle #" << m_vin << ": Parameterized-ctor"<< std::endl;
}

Vehicle::Vehicle(const Vehicle & copy): m_vin (s_idgen++){
    for (int i =0 ; i < 3 ; i++){
        m_lla[i] = copy.m_lla[i];
    }
    std:: cout << "Vehicle #" << m_vin << ": Copy-ctor"<< std::endl;
}

Vehicle::~Vehicle (){ //how to code this??
    std:: cout << "Vehicle #" << m_vin << ": Dtor"<< std::endl;
}

Vehicle & Vehicle::operator = (const Vehicle & rhs){
    //am i using the same vin?
    setLLA(rhs.m_lla);
    return *this;
}

std::ostream & operator<< (std::ostream & output, const Vehicle & vehicle){
    output<< "Vehicle #" << vehicle.m_vin << " @ [" << vehicle.m_lla[0]<< ", "<< vehicle.m_lla[1]<< ", " << vehicle.m_lla[2]<< "]"<< std::endl;
    return output;
}

float Vehicle::getLLA(int index) const{
    return m_lla[index];
}

int Vehicle::getVIN() const {
    return m_vin;
}

void Vehicle::setLLA(const float *LLA){
    for (int i = 0; i<3 ; i++){
        m_lla[i]= *LLA;
        LLA++; 
    }
}

//  void Vehicle::setVIN (const int vin){
//      if (s_idgen == vin || s_idgen> vin ){
//         return;
//     }
//     else if (s_idgen < vin){
//         s_idgen = vin;
//     }
    
//  }


void Vehicle::move(const float *LLA){
    setLLA(LLA);
    std:: cout << "Vehicle #" << m_vin << ": CAN'T MOVE- I DON'T KNOW HOW"<< std::endl;
}

int Vehicle::getIdgen (){
    return s_idgen;
}

bool Vehicle::vinCheck(int vin){
    if (s_idgen == vin || s_idgen> vin ){
        return 0;
    }
    else{
        s_idgen = vin;
        s_idgen++;
        return 1;
    }
}

