/**
 *  @Student: Siu, Cicelia
 *  @Date: February 9, 2020
 *  @Project: 3. Rental Car Dealership with Multiple Agencies
 */

#include <iostream>
#include <fstream>
#include "my_string.h"
#include "RentalCar.h"
#include "Agency.h"
#include "menu.h"

//default Constructor
RentalCar::RentalCar(){
    m_year = 0;
    myStringCopy(m_make, "N/A");
    myStringCopy(m_model, "N/A");
    m_price = .0;
    m_available = false;
}

//paramaterized Constructor
RentalCar::RentalCar(int year, char* make, char* model, float price, bool available) {
    m_year = year;
    myStringCopy(m_make, make);
    myStringCopy(m_model, model);
    m_price = price;
    m_available = available;
}
//get funtions
int RentalCar::getYear() const{
    return m_year;
}

char * RentalCar::getMake() {
    return m_make;
}
char * RentalCar::getModel(){
    return m_model;
}
float RentalCar::getPrice() const{
    return m_price;
}
bool RentalCar::getAvailable() const{
    return m_available;
}

//set functions
void RentalCar::setYear(int year){
    m_year = year;
}

void RentalCar::setMake(char* make){
    myStringCopy(m_make, make);
}

void RentalCar::setModel(char* model){
    myStringCopy(m_model, model);
}

void RentalCar::setPrice(float price){
    m_price = price;
}

void RentalCar::setAvailable (bool available){
    m_available = available;
}

//etc methods
void RentalCar::print() {
    std::cout << RentalCar::getYear() << " " << RentalCar::getMake() << " " << RentalCar::getModel() << ", $ " << RentalCar::getPrice() << " per day, Available:  " << std::boolalpha << m_available << std::endl;
}

void RentalCar::estimateCost(int rentDays){
    float rental_cost = RentalCar::getPrice() * rentDays;
    std::cout<< "The estimated cost for the " << RentalCar::getYear() << " "<< RentalCar::getMake() << " "<< RentalCar::getModel() << " is $" << rental_cost << " for " << rentDays<< " days."<< std::endl;

}
