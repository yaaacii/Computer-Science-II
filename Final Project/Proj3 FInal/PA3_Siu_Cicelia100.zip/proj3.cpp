/**
 *  @Student: Siu, Cicelia
 *  @Date: February 9, 2020
 *  @Project: 3. Rental Car Dealership with Multiple Agencies
 */

#include <iostream>
#include <fstream>

#include "Agency.h"
#include "RentalCar.h"
#include "menu.h"
#include "my_string.h"


int main(){
    RentalAgency dealerships[3];
    int menuchoice = 0;
    do {
        userMenuPrompt(menuchoice);
        switch (menuchoice){
            case 1:
                readCars(dealerships);
                break;
            case 2:
                printAgenciesToTerminal(dealerships);
                break;
            case 3:
                estimateRentalCost(dealerships);
                break;
            case 4:
                findCheapestRental(dealerships);
                break;
            case 5:
                reserveCar(dealerships);
                break;
            default:
                break;
        }
    } while (menuchoice != 6);
    return 0;
}
