/**
 *  @Student: Siu, Cicelia
 *  @Date: February 9, 2020
 *  @Project: 3. Rental Car Dealership with Multiple Agencies
 */


#ifndef AGENCY_H_
#define AGENCY_H_
#include <iostream>
#include <fstream>
#include "RentalCar.h"

struct RentalAgency{
    char name [256];
    int zipcode [5];
    RentalCar inventory [5];

};

#endif
