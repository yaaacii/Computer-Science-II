/**
 *  @Student: Siu, Cicelia
 *  @Date: February 9, 2020
 *  @Project: 3. Rental Car Dealership with Multiple Agencies
 */

#include <iostream>
#include <fstream>
#include "my_string.h"
#include "menu.h"
#include "RentalCar.h"
#include "Agency.h"

void readCars(RentalAgency * agency){
    char inputfile[100];
    
    std:: cout << "Please enter an input file:" << std::endl;
    std:: cin >> inputfile;
    std::ifstream inputstream;
    inputstream.open (inputfile);
    if (!inputstream){
        std::cerr << "File does not exist" << std:: endl;
        return;
    }
    int i = 0;
    int j = 0;
    int zipcode;
    int temp;
    for (j = 0; j <3; j++){
        //set agency name
        inputstream >> agency->name >> zipcode;
        int * zipPt;
        zipPt = agency->zipcode;
        zipPt +=4;
        //set zipcode
        while(zipcode != 0){
            temp = zipcode%10;
            *zipPt = temp;
            zipcode = zipcode/10;
            zipPt--;
        }


        //set year, make, model, price, and availablity
        RentalCar *inventoryPt = agency->inventory;
        for (i = 0; i < 5; i++){
            //temperary variables for the set functions
            int year;
            char make [256];
            char model [256];
            float price;
            bool available;

            inputstream >> year >> make >> model >> price >>available;
            inventoryPt->setYear(year);
            inventoryPt->setMake(make);
            inventoryPt->setModel(model);
            inventoryPt->setPrice(price);
            inventoryPt->setAvailable(available);
            inventoryPt++;

        }
        agency++;
    }
    std::cout << std::endl;
    inputstream.close();
}

void printAgenciesToTerminal(RentalAgency * agency){
    int i = 0;
    int j = 0;
    //print out all three agencies and their cars
    std:: cout << "Agencies and their cars" << std::endl;
    for (j = 0; j<3; j++){
        //print agency names and zipcodes
        std::cout << agency->name << " ";
        int* zipcodePt = agency->zipcode;
        int k = 0;
        while (k < 5){ 
            std::cout << *zipcodePt;
            zipcodePt++;
            k++;
        }
        std::cout << std::endl;

        //print out all 5 cars in the agency
        RentalCar * inventoryPt = agency->inventory;
        for (i = 0; i < 5; i++){
            inventoryPt -> RentalCar::print();
            inventoryPt++;
        }
        //go to the next agency
        std::cout <<std::endl;
        agency++;
    }
}

void estimateRentalCost(RentalAgency * agency){
    RentalAgency * agencyOrg = agency;
    int rentDays = 0;
    int agencyChoice = 0;
    int carChoice = 0;

    //ask for the agency
    std::cout << "Which agency would you like to choose your rental from?" << std:: endl;
    for(int j= 1; j<4; j++){
        std:: cout << "["<< j<< "] "<< " " << agency->name << std:: endl;
        agency++;
    }
    std::cin >>agencyChoice;
    if (agencyChoice < 1 || agencyChoice > 3){
        std:: cout <<"Invalid Choice"<< std::endl;
        return;
    }
    agencyChoice = (agencyChoice-1);
    agency = agencyOrg; //resetting back to base adress
    agency += agencyChoice;

    //ask for car
    RentalCar * carPt = agency->inventory;
    std::cout<< "Which car from " << agency->name <<" would you like?"<< std::endl;
    for(int i= 1; i<6; i++){
        std:: cout << "[" << i << "]";
        carPt->RentalCar::print();
        carPt++;
    }
    std:: cin >> carChoice;
    if (carChoice < 1 || carChoice > 5){
        std:: cout <<"Invalid Choice"<< std::endl;
        return;
    }
    carPt = agency->inventory;
    carPt += (carChoice - 1);

    //ask for the rental period
    std:: cout << "How many days would you like to rent the car out for?" << std::endl;
    std:: cin >> rentDays;

    //calculate price and print price
    carPt->RentalCar::estimateCost (rentDays);
}


void findCheapestRental (RentalAgency * agency){
    RentalCar *inventoryPt;
    inventoryPt = agency->inventory;
    RentalCar * cheapestPt = agency->inventory;
    //find cheapest through all cars of the agency then do it 2 more times for each agency
    for(int agencies = 0; agencies < 3; agencies++){
        inventoryPt = agency->inventory;
        for (int j = 0; j < 5; j++){
            if (inventoryPt->RentalCar::getAvailable() == 1){ //check if car is available
                if (cheapestPt->getPrice() > inventoryPt->getPrice()){// overwrite if price is cheaper
                    cheapestPt = inventoryPt;
                }
            }
            inventoryPt++;
        }
        agency++;
    }
    std::cout << "The cheapest car that is available is the ";
    std::cout<< cheapestPt->getYear() << " "<< cheapestPt->getMake()<< " "<< cheapestPt->getModel()<< " at $"<< cheapestPt->getPrice()<< " per day."<< std::endl;
}

void reserveCar(RentalAgency * agency){
    RentalAgency * agencyOrg = agency;
    int rentDays = 0;
    int agencyChoice = 0;
    int carChoice = 0;

    //ask for the agency
    std::cout << "Which agency would you like to choose your rental from?" << std:: endl;
    for(int j= 1; j<4; j++){
        std:: cout << "["<< j<< "] "<< " " << agency->name << std:: endl;
        agency++;
    }
    std::cin >>agencyChoice;
    if (agencyChoice < 1 || agencyChoice > 3){
        std:: cout <<"Invalid Choice"<< std::endl;
        return;
    }
    agencyChoice = (agencyChoice-1);
    agency = agencyOrg; //resetting back to base adress
    agency += agencyChoice;

    //ask for car
    RentalCar * carPt = agency->inventory;
    std::cout<< "Which car from " << agency->name <<" would you like?"<< std::endl;
    for(int i= 1; i<6; i++){
        std:: cout << "[" << i << "]";
        carPt->RentalCar::print();
        carPt++;
    }
    std:: cin >> carChoice;
    if (carChoice < 1 || carChoice > 5){
        std:: cout <<"Invalid Choice"<< std::endl;
        return;
    }
    carPt = agency->inventory;
    carPt += (carChoice - 1);
    if (carPt->getAvailable() == 0){
        std:: cout <<"This car is unavailable. Please choose another one."<< std::endl;
        return;
    }

    //ask for the rental period
    std:: cout << "How many days would you like to rent the car out for?" << std::endl;
    std:: cin >> rentDays;
    
    carPt->setAvailable(0);
    std:: cout << "The "<< carPt->getYear() << " " << carPt->getMake() << " "<< carPt->getModel()<< " is now rented to you at a total cost of $"<< rentDays*carPt->getPrice() << std::endl;
    std::cout <<"Refeshing list.."<< std::endl;
	agency = agencyOrg;
    printAgenciesToTerminal(agency);
}

void userMenuPrompt (int &menuchoice){
    std::cout << "Car Dealership\n================\n1. Input agencies and their cars from a file \n2. Show Cars and their Agency in Terminal\n3. Estimate Rental Cost\n4. Find the cheapest rental car.\n5. Reserve a car and Refresh the list\n6. Exit " << std:: endl;
    std:: cin >> menuchoice;
}

