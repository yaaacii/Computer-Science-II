/**
 *  @Student: Siu, Cicelia
 *  @Date: February 9, 2020
 *  @Project: 3. Rental Car Dealership with Multiple Agencies
 */

#ifndef RENTALCAR_H_
#define RENTALCAR_H_
#include <iostream>
#include <fstream>

class RentalCar{
    public:
        RentalCar();
        RentalCar(int year, char* make, char* model, float price, bool available = 0);
        int getYear() const;
        void setYear( int year);
        char * getMake();
        void setMake( char * make);
        char * getModel ();
        void setModel (char * model);
        float getPrice () const;
        void setPrice (float price);
        bool getAvailable () const;
        void setAvailable (bool available);
        void print();
        void estimateCost(int rentalDays);
    private:
        float m_price;
        int m_year;
        bool m_available;
        char m_make [256];
        char m_model [256];
};


#endif
