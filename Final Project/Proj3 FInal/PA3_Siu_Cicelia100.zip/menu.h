/**
 *  @Student: Siu, Cicelia
 *  @Date: February 9, 2020
 *  @Project: 3. Rental Car Dealership with Multiple Agencies
 */


#ifndef MENU_H_
#define MENU_H_
#include <iostream>
#include <fstream>
#include "RentalCar.h"
#include "Agency.h"

/**read information of the cars and put into an class and structs
 * @param agency name of the struct for the agencies
 * @pre must have a file with information of the cars
 * @post will have the information from the file put into their structs and classes
 */
void readCars(RentalAgency * agency);

/**will read the structs and classes of the agencies and will output its information to the terminal
 * @param agency name of the struct for the agencies
 * @pre must have the array of car structs filled by reading cars from a file
 * @post will show information to the terminal
 */
void printAgenciesToTerminal(RentalAgency * agency);


/**given the amount of days, the function will find the total cost of the rent for the cars that are available
 * @param agency name of the struct for the agencies
 * @pre must have structs and classes filled with information 
 * @pre a user input of how many days the car will be rented out with the agency and the car
 * @post will print to the terminal the estimated cost to rent the car
 */
void estimateRentalCost(RentalAgency * agency);

/**will find the cheapest car out of all of the cars and print it to the terminal
 * @param agency name of the struct for the agencies
 * @pre must have structs and classes filled with information 
 * @pre user must input how many days to rent and the index of the car and agency
 * @post will set the cars availability to false
 * @post will show the terminal that the car has been rented out to the user and the total cost
 */
void findCheapestRental (RentalAgency * agency);
/**will reserve the car for the user given which car and for how many days then once reserved, refresh the page
 * @param agency name of the struct for the agencies
 * @pre must have structs and classes filled with information 
 * @pre user must input how many days to rent and the index of the car and agency
 * @post will set the cars availability to false
 * @post will show the terminal that the car has been rented out to the user and the total cost
 */
void reserveCar(RentalAgency * agency);

/**asks the user to ender a menu choice to execute the menu
 * @param menuchoice a pass by reference for menu choice to change the menu choice variable to the user input
 * @pre user should put in a number for the menu at which user wants to do
 * @post will change the parameter's menuchoice variable to the int of which the user inputted
 */
void userMenuPrompt (int &menuchoice);

#endif
