/**
 * @brief  CS-202 Project 7 MyString class .cpp file
 * @Author Cicelia Siu
 *
 * This file is the .cpp file to implement the MyString class for Project 7
 */


#include "SmartPtr.h"

int main(){
    std::cout<<std::endl << "----------TESTS START------------" << std::endl;
    //(1) 
    std::cout << "Testing SmartPtr Default ctor" << std::endl;
    SmartPtr sp1;// Default-ctor
    sp1->setIntVal(1);
    sp1->setDoubleVal(0.25);
    std::cout<< "Dereference Smart Pointer 1: "<< *sp1 <<std::endl;


    //(2)
    std::cout<< std::endl << "Testing SmartPtr Copyctor" << std::endl;
    SmartPtr sp2= sp1;// Copy-initalization (Copy-ctor)
    sp2->setIntVal(2);
    sp2->setDoubleVal(0.5);
    std::cout<< "Dereference Smart Pointer 1: "<< *sp1 <<std::endl;
    std::cout<< "Dereference Smart Pointer 2: "<< *sp2 <<std::endl;
   
    //(8) 
    std::cout << "Testing SmartPtr Assignment operator=" << std::endl;
    SmartPtr sp3;
    sp3 = sp1;// Assignment operator
    sp3->setIntVal(4);
    sp3->setDoubleVal(0.0);
    std::cout << "Dereference Smart Pointer 1: " << *sp1 << std::endl;
    std::cout<< "Dereference Smart Pointer 2: "<< *sp2 << std::endl;
    std::cout << "Dereference Smart Pointer 3: "<< *sp3 << std::endl;


    std::cout<<"Testing SmartPtr Parametrized ctor with NULL data"<<std::endl;
    SmartPtr spNull( NULL);  // NULL-data initialization

    std::cout<<"Testing SmartPtr Copy ctor with NULLdata SmartPtr"<<std::endl;
    SmartPtr spNull_cpy( spNull );

   std::cout<< std::endl<<"Testing SmartPtr Assignment with NULLdata SmartPtr"<<std::endl;
   SmartPtr spNull_assign;
   spNull_assign = spNull;  // NULL-data assign
   
   std::cout<< std::endl << "End-of-Scope, Destructors called in reverse order of SmartPtr creation\n(spNull_assign, spNull_cpy, spNull, sp3, sp2, sp1): "<< std::endl;

    std::cout << "------------End of Tests------------" << std::endl;
}
