/**
 * @brief  CS-202 SmartPtr class Implementation
 * @author Cicelia Siu
 *
 * This file contains the implementation of a smart pointer SmartPtr class for the purposes of CS-202.
 */
#include "SmartPtr.h"

SmartPtr::SmartPtr(){
    try{
        m_ptr = new DataType;
        m_refcount = new size_t;
        (*m_refcount) = 1;
    } catch (std::bad_alloc & error) {
        error.what();
    }
    std:: cout << "SmartPtr Default Constructor for new allocation, RefCount= " << *m_refcount << std::endl;
} 

SmartPtr::SmartPtr( DataType * data){
    //dynamically allocate refcount first
    try{
        m_refcount = new size_t;
    } catch (std::bad_alloc & error) {
        error.what();
    }
    //check data if null or not
    if (data) {
        *m_refcount = 1;
    } else {
        *m_refcount = 0;
    }
    m_ptr = data;
    std:: cout << "SmartPtr Parametrized Constructor from data pointer, RefCount= " << *m_refcount << std::endl;
}

SmartPtr::SmartPtr( const SmartPtr & other){
    //check m_ptr of other to see if it should be newly allocated or not
    if (other.m_ptr){
        m_refcount = other.m_refcount;
        (*m_refcount)++;
    } else {
        try{
            m_refcount = new size_t;
			*m_refcount = 0;
        } catch (std::bad_alloc & error) {
            error.what();
        }
    }
    m_ptr = other.m_ptr;
    std:: cout << "SmartPtr Copy Constructor, RefCount= " << *m_refcount << std::endl;
}

SmartPtr::~SmartPtr(){
    //decrement
	if(*m_refcount != 0){
    	(*m_refcount)--;
	}

    std::cout<< "SmartPtr Destructor, RefCount= " << *m_refcount << std::endl;
    //check if it is the last one, if so, deallocate
    if ((*m_refcount) <= 0){
        delete m_ptr;
        delete m_refcount;
    }
}

SmartPtr & SmartPtr::operator=(const SmartPtr & rhs){
    if (this != &rhs){
        //from destructor to check if it is the last one
        if (--(*m_refcount) <= 0){
            delete m_ptr;
		delete m_refcount;
        }

        //from copy constructor
        if (rhs.m_ptr){
            m_refcount = rhs.m_refcount;
            (*m_refcount)++;
        } else {
            try{
                m_refcount = new size_t;
		*m_refcount = 0;
            } catch (std::bad_alloc & error) {
                error.what();
            }
        }
        m_ptr = rhs.m_ptr;
    }
    std:: cout << "SmartPtr Copy Assignment, RefCount= " << *m_refcount << std::endl;
return *this;
}

DataType & SmartPtr::operator*(){
    //lol just dereference the m_ptr and return it
    return *m_ptr;
}

DataType * SmartPtr::operator->(){
    return m_ptr;
}





