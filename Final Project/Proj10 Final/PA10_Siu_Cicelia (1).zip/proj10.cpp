/**
 * @brief  CS-202 Project 10  main .cpp file
 * @Author Cicelia Siu
 *
 * This file is the main .cpp file to test all functions for Project 10
 */



#include "ArrayStack/ArrayStack.hpp"
#include "NodeStack/Node.hpp"
#include "NodeStack/NodeStack.hpp"

int main (){

    std::cout << std::endl << "-----------------Testing Array Based List------------------" << std::endl;

    std::cout << std::endl << "Testing Default Ctor" << std::endl;
    ArrayStack<int> asStackDef1;
    ArrayStack<double> asStackDef2;
    std::cout << std::endl << "Printing Array Stack Def INT w/ nothing: " << std::endl << asStackDef1 << std::endl;
    std::cout << std::endl << "Printing Array Stack Def DOUBLE w/ nothing: " << std::endl << asStackDef2 << std::endl;
    
    std::cout << std::endl << "Testing Parameterized Ctor" << std::endl;
    ArrayStack<int> asStack1(2, 2);
    ArrayStack<double> asStack2(2, 2.4);
    std::cout << std::endl << "Printing Array Stack 1 INT w/ (2, 2) : " << std::endl << asStack1 << std::endl;
    std::cout << std::endl << "Printing Array Stack 2 DOUBLE w/ (2, 2.4): " << std::endl << asStack2 << std::endl;

    std::cout << std::endl << "Testing Copy Ctor" << std::endl;
    ArrayStack<int> asStack3(asStack1);
    ArrayStack<double> asStack4(asStack2);
    std::cout << std::endl << "Printing Array Stack 1 INT w/ (2, 2) : " << std::endl << asStack1 << std::endl;
    std::cout << std::endl << "Printing Array Stack 2 DOUBLE w/ (2, 2.4): " << std::endl << asStack2 << std::endl;
    std::cout << std::endl << "Printing Array Stack 3 INT w/ (2, 2) : " << std::endl << asStack3 << std::endl;
    std::cout << std::endl << "Printing Array Stack 4 DOUBLE w/ (2, 2.4): " << std::endl << asStack4 << std::endl;

    std::cout << std::endl << "Testing in Array Stack 2 DOUBLE: push(3.6) and in Array Stack 1 INT: pop()" << std::endl;
    asStack2.push(3.6);
    asStack1.pop();
    std::cout << std::endl << "Printing Array Stack 1 INT: " << std::endl << asStack1 << std::endl;
    std::cout << std::endl << "Printing Array Stack 2 DOUBLE: " << std::endl << asStack2 << std::endl;


    std::cout << std::endl << "Testing and Printing Array Stack 1 and 2: top() = " << std::endl;
    std::cout << std::endl << "Array Stack 1 INT's top =  " << std::endl << asStack1.top() << std::endl;
    std::cout << std::endl << "Array Stack 2 DOUBLE's top =  " << std::endl << asStack2.top() << std::endl;
    

    std::cout << std::endl << "Testing Assignment Operator : Array Stack 1 INT = Array Stack 3 INT and Array Stack 2 DOUBLE = Array Stack 4 DOUBLE " << std::endl;
    asStack1 = asStack3;
    asStack2 = asStack4;
    std::cout << std::endl << "Printing Array Stack 1 INT: " << std::endl << asStack1 << std::endl;
    std::cout << std::endl << "Printing Array Stack 2 DOUBLE: " << std::endl << asStack2 << std::endl;
    std::cout << std::endl << "Printing Array Stack 3 INT: " << std::endl << asStack3 << std::endl;
    std::cout << std::endl << "Printing Array Stack 4 DOUBLE: " << std::endl << asStack4 << std::endl;

    std::cout << std::endl << "Testing in clear() for all Array Stacks" << std::endl;
    asStack1.clear();
    asStack2.clear();
    asStack3.clear();
    asStack4.clear();
    std::cout << std::endl << "Printing Array Stack 1 INT: " << std::endl << asStack1 << std::endl;
    std::cout << std::endl << "Printing Array Stack 2 DOUBLE: " << std::endl << asStack2 << std::endl;
    std::cout << std::endl << "Printing Array Stack 3 INT: " << std::endl << asStack3 << std::endl;
    std::cout << std::endl << "Printing Array Stack 4 DOUBLE: " << std::endl << asStack4 << std::endl;

    std::cout << std::endl << "-----------------End of Array Based List Tests------------------" << std::endl;



    std::cout << std::endl << "-----------------Testing Node Based List------------------" << std::endl;

    std::cout << std::endl << "Testing Default Ctor" << std::endl;
    NodeStack<int> nStackDef1;
    NodeStack<double> nStackDef2;
    std::cout << std::endl << "Printing Node Stack Def INT w/ nothing: " << std::endl << nStackDef1 << std::endl;
    std::cout << std::endl << "Printing Node Stack Def DOUBLE w/ nothing: " << std::endl << nStackDef2 << std::endl;

    std::cout << std::endl << "Testing Parameterized Ctor" << std::endl;
    NodeStack<int> nStack1(2, 2);
    NodeStack<double> nStack2(2, 2.4);
    std::cout << std::endl << "Printing Node Stack 1 INT w/ {2, 2}: " << std::endl << nStack1 << std::endl;
    std::cout << std::endl << "Printing Node Stack 2 DOUBLE w/ {2, 2.4}: " << std::endl << nStack2 << std::endl;

    std::cout << std::endl << "Testing Copy Ctor" << std::endl;
    NodeStack<int> nStack3(nStack1);
    NodeStack<double> nStack4(nStack2);
    std::cout << std::endl << "Printing Node Stack 1 INT w/ {2, 2}: " << std::endl << nStack1 << std::endl;
    std::cout << std::endl << "Printing Node Stack 2 DOUBLE w/ {2, 2.4}: " << std::endl << nStack2 << std::endl;
    std::cout << std::endl << "Printing Node Stack 3 INT w/ {2, 2}: " << std::endl << nStack3 << std::endl;
    std::cout << std::endl << "Printing Node Stack 4 DOUBLE w/ {2, 2.4}: " << std::endl << nStack4 << std::endl;

    std::cout << std::endl << "Testing in Node Stack 2 DOUBLE: push(3.6) and in Node Stack 1 INT: pop()" << std::endl;
    nStack2.push(3.6);
    nStack1.pop();
    std::cout << std::endl << "Printing Node Stack 1 INT: " << std::endl << nStack1 << std::endl;
    std::cout << std::endl << "Printing Node Stack 2 DOUBLE: " << std::endl << nStack2 << std::endl;

    std::cout << std::endl << "Testing and Printing Node Stack 1 and 2: top() = " << std::endl;
    std::cout << std::endl << "Node Stack 1 INT's top =  " << std::endl << nStack1.top() << std::endl;
    std::cout << std::endl << "Node Stack 2 DOUBLE's top =  " << std::endl << nStack2.top() << std::endl;

    std::cout << std::endl << "Testing Assignment Operator : Node Stack 1 = Node Stack 2" << std::endl;
    nStack1 = nStack3;
    nStack2  = nStack4;
    std::cout << std::endl << "Printing Node Stack 1 INT: " << std::endl << nStack1 << std::endl;
    std::cout << std::endl << "Printing Node Stack 2 DOUBLE: " << std::endl << nStack2 << std::endl;
    std::cout << std::endl << "Printing Node Stack 3 INT: " << std::endl << nStack3 << std::endl;
    std::cout << std::endl << "Printing Node Stack 4 DOUBLE: " << std::endl << nStack4 << std::endl;

    std::cout << std::endl << "Testing in clear() for all Node Stacks" << std::endl;
    nStack1.clear();
    nStack2.clear();
    nStack3.clear();
    nStack4.clear();
    std::cout << std::endl << "Printing Node Stack 1 INT: " << std::endl << nStack1 << std::endl;
    std::cout << std::endl << "Printing Node Stack 2 DOUBLE: " << std::endl << nStack2 << std::endl;
    std::cout << std::endl << "Printing Node Stack 3 INT: " << std::endl << nStack3 << std::endl;
    std::cout << std::endl << "Printing Node Stack 4 DOUBLE: " << std::endl << nStack4 << std::endl;

    std::cout << std::endl << "-----------------End of Node Based List Tests------------------" << std::endl;

}
