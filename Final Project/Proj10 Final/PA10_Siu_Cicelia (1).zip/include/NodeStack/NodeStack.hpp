/**
 * @brief  CS-202 Project 10 NodeStack class .hpp file
 * @Author Cicelia Siu
 *
 * This file is the .hpp file to declare and implement the Node Stack class for Project 10
 */



#ifndef NODESTACK_HPP_
#define NODESTACK_HPP_

#include "Node.hpp"

//NodeStack Declarations
template <typename T> class NodeStack;
template <typename T> std::ostream & operator<<(std::ostream& os, const NodeStack<T> & nodeStack);

template <typename T>
class NodeStack{
    friend std::ostream & operator<<(std::ostream& os, const NodeStack<T> & nodeStack){
    	nodeStack.serialize(os);
    	return os;
} 
    public:
        NodeStack();//(1)
        NodeStack(size_t count, const T & value);//(2)
        NodeStack(const NodeStack<T> & other);//(3)
        ~NodeStack();//(4)
        NodeStack<T> & operator= (const NodeStack<T> & rhs);//(5)
        T & top();//(6a)
        const T & top() const;//(6b)
        void push(const T & value);//(7)
        void pop();//(8)
        size_t size() const;//(9)
        bool empty() const;//(10)
        bool full() const;//(11)
        void clear();//(12)
        void serialize(std::ostream & os)const;//(13)
    private:
        Node<T> * m_top;
};


//NodeStack Implementations

template <typename T>
NodeStack<T>::NodeStack(){
    m_top = NULL;
}
template <typename T>
NodeStack<T>::NodeStack(size_t count, const T & value){
    m_top = NULL;

    for (size_t i = 0; i < count; i++){
        push(value);
    }
}

template <typename T> //diff
NodeStack<T>::NodeStack(const NodeStack<T> & other){
    m_top = NULL;

    Node<T> * curr = other.m_top;
    for (size_t i = 0; i < other.size(); i++, curr = curr->m_next){
        push(curr->data());
    }
}

template <typename T>
NodeStack<T>::~NodeStack(){
    clear();
}

template <typename T> //diff
NodeStack<T> & NodeStack<T>::operator= (const NodeStack<T> & rhs){
    clear();
    m_top = NULL;

    Node<T> * curr = rhs.m_top;
    for (size_t i = 0; i < rhs.size(); i++, curr = curr->m_next){
        push(curr->data());
    }
    return *this;
}

template <typename T>
T & NodeStack<T>::top(){
    return m_top->data();
}

template <typename T>
const T & NodeStack<T>::top() const{
    return m_top->data();
}

template <typename T>
void NodeStack<T>::push(const T & value){
	if (empty()){
		m_top = new Node<T>(value);
	} else {
        m_top = new Node<T>(value, m_top);
    }
}

template <typename T>
void NodeStack<T>::pop(){
    if (!empty()){
		Node<T> * ptr = m_top;
		m_top = m_top->m_next;
		delete ptr;
	}
}

template <typename T>
size_t NodeStack<T>::size() const{
    Node<T> * curr = m_top;
    size_t count = 0;

    while (curr != NULL){
        curr = curr->m_next;
        count++;
    }
    return count;
}

template <typename T>
bool NodeStack<T>::empty() const{
    if (m_top == NULL){
        return 1;
    } else {
        return 0;
    }
}

template <typename T>
bool NodeStack<T>::full() const{
    return false;
}

template <typename T>
void NodeStack<T>::clear(){
    Node<T> * curr = m_top;
    Node<T> * deleteNode = nullptr;

    while (curr != NULL){
        deleteNode = curr;
        curr = curr->m_next;
        delete deleteNode;

    }
    m_top = NULL;
}

template <typename T>
void NodeStack<T>::serialize(std::ostream & os)const{
    Node<T> * curr = m_top;
    for (size_t i = size() -1; curr != NULL; curr = curr->m_next, i--){
		os << i << ". " << curr->data() << std::endl;
	}
}
#endif
