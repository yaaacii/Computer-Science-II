/**
 * @brief  CS-202 Project 10 Node class .hpp file
 * @Author Cicelia Siu
 *
 * This file is the .hpp file to declare and implement the Node class for Project 10
 */


#ifndef NODE_HPP_
#define NODE_HPP_

#include <iostream>

//Node Declarations

template <typename> class Node;
template <typename> class NodeStack;
template <typename T>
class Node{

    friend class NodeStack<T>;  //allows direct accessing of link and data from class NodeList
    public:
        Node();
        Node(const T & data, Node<T> * next = NULL);
        T & data();
        const T & data() const;
    private:
        Node<T> * m_next; 						
        T m_data;
}; 

//Node Implementations
template <typename T>
Node<T>::Node(){
    m_data = NULL;
}

template <typename T>
Node<T>::Node(const T & data, Node<T> * next){
    m_next = next;
    m_data = data;
}

template <typename T>
T & Node<T>::data(){  
    return m_data;
}

template <typename T>
const T & Node<T>::data() const{  
    return m_data;
}

#endif
