/**
 * @brief  CS-202 Project 10 Array Stack class .hpp file
 * @Author Cicelia Siu
 *
 * This file is the .hpp file to declare and implement the Array Stack class for Project 10
 */



#ifndef ARRAYSTACK_HPP_
#define ARRAYSTACK_HPP_

#include <iostream>

//ArrayStack Declarations
template <typename T, size_t MAX_STACKSIZE = 10> class ArrayStack;

template <typename T, size_t MAX_STACKSIZE> std::ostream & operator<< (std::ostream & os, const ArrayStack <T, MAX_STACKSIZE> & arrayStack);

template <typename T, size_t MAX_STACKSIZE>
class ArrayStack{
    friend std::ostream & operator<< <>(std::ostream&os, const ArrayStack<T, MAX_STACKSIZE> & arrayStack); 
    public:
        ArrayStack();//(1)
        ArrayStack(size_t count, const T & value);//(2)
        ArrayStack(const ArrayStack<T, MAX_STACKSIZE> & other);//(3)
        ~ArrayStack();//(4)
        ArrayStack<T, MAX_STACKSIZE> & operator=(const ArrayStack<T, MAX_STACKSIZE> & rhs);//(5)
        T & top();//(6a)
        const T & top() const;//(6b)
        void push(const T & value);//(7)
        void pop();//(8)
        size_t size() const;//(9)
        bool empty() const;//(10)
        bool full() const;//(11)
        void clear();//(12)
        void serialize(std::ostream & os)const;//(13)
    private:
        T m_container[MAX_STACKSIZE];
        size_t m_top;
};


//ArrayStack Implementations

template <typename T, size_t MAX_STACKSIZE> 
std::ostream & operator<<(std::ostream & os, const ArrayStack<T, MAX_STACKSIZE> & arrayQueue){
    arrayQueue.serialize(os);
    return os;
} 

template <typename T, size_t MAX_STACKSIZE>
ArrayStack<T, MAX_STACKSIZE>::ArrayStack(){
    m_top = 0;

}

template <typename T, size_t MAX_STACKSIZE>
ArrayStack<T, MAX_STACKSIZE>::ArrayStack(size_t count, const T & value){
    m_top = 0;

    for (int i = 0; i < count; i++){
        push (value);
    }
}

template <typename T, size_t MAX_STACKSIZE>
ArrayStack<T, MAX_STACKSIZE>::ArrayStack(const ArrayStack<T, MAX_STACKSIZE> & other){
    m_top = 0;

    for (size_t i = 0; i < other.size(); i++){
        push(other.m_container[i]);              //different
    }
}

template <typename T, size_t MAX_STACKSIZE>
ArrayStack<T, MAX_STACKSIZE>::~ArrayStack(){
   //no allocation so nothing happens
}

template <typename T, size_t MAX_STACKSIZE>
ArrayStack<T, MAX_STACKSIZE> & ArrayStack<T, MAX_STACKSIZE>::operator=(const ArrayStack<T, MAX_STACKSIZE> & rhs){
    clear();
    for (size_t i = 0; i < rhs.size(); i++){
        push(rhs.m_container[i]);              //different
    }
    return *this;
}

template <typename T, size_t MAX_STACKSIZE>
T & ArrayStack<T, MAX_STACKSIZE>::top(){
    return m_container[m_top-1];
}

template <typename T, size_t MAX_STACKSIZE>
const T & ArrayStack<T, MAX_STACKSIZE>::top() const{
    return m_container[m_top-1];
}


template <typename T, size_t MAX_STACKSIZE>
void ArrayStack<T, MAX_STACKSIZE>::push(const T & value){
    if (!full()){
        m_container[m_top] = value;
        m_top++;
    } else {
        std::cout << "The array is full" <<std::endl;
    }
}

template <typename T, size_t MAX_STACKSIZE>
void ArrayStack<T, MAX_STACKSIZE>::pop(){
    if (!empty()){
        --m_top;
    }
}

template <typename T, size_t MAX_STACKSIZE>
size_t ArrayStack<T, MAX_STACKSIZE>::size() const{
    return m_top;
}

template <typename T, size_t MAX_STACKSIZE>
bool ArrayStack<T, MAX_STACKSIZE>::empty() const{
    if (m_top == 0){
        return 1;
    } else {
        return 0;
    }
}

template <typename T, size_t MAX_STACKSIZE>
bool ArrayStack<T, MAX_STACKSIZE>::full() const{
    if (m_top >= MAX_STACKSIZE){
        return 1;
    } else {
        return 0;
    }
}

template <typename T, size_t MAX_STACKSIZE>
void ArrayStack<T, MAX_STACKSIZE>::clear(){
    m_top = 0;
}

template <typename T, size_t MAX_STACKSIZE>
void ArrayStack<T, MAX_STACKSIZE>::serialize(std::ostream & os)const{
    for (int i = size() - 1; i >= 0 ; i--){
        os << i << ". " << m_container[i]<< std::endl;
    }

}

#endif
