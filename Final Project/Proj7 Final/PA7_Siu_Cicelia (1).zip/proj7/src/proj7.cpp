/**
 * @brief  CS-202 Project 7 MyString class .cpp file
 * @Author Cicelia Siu
 *
 * This file is the .cpp file to implement the MyString class for Project 7
 */


#include "MyString.h"

int main(){

	//(1) 
	std::cout << "Testing Default ctor" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_default;
	std::cout << std::endl << std::endl;

	//(2)
	std::cout << "Testing Parametrized ctor" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_parametrized("This is MyString parametrized cString!");
	std::cout << ms_parametrized.c_str() <<std::endl << std::endl;

	//(3)
	std::cout << "Testing Copy ctor" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_copy(ms_parametrized);
	std::cout << ms_copy.c_str()<< std::endl << std::endl;

	//(4)
	std::cout << "Testing dtor" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString * ms_destroy = new MyString("MyString to be destroyed...");
	delete ms_destroy;
	ms_destroy = NULL;
	std::cout << std::endl << std::endl;
        
	//(5),(6)
	std::cout << "Testing size and length" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_size_length("Size and length test");
	std::cout << "Testing size()" << std::endl;
	std::cout << ms_size_length.size() << std::endl;
	std::cout << "Testing length()" << std::endl;
	std::cout << ms_size_length.length() << std::endl;
	std::cout << std::endl << std::endl;

	//(7)
	std::cout << "Testing c_str()" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_toCstring("C-String equivalent successfully obtained!");
	std::cout << ms_toCstring.c_str() << std::endl;
	std::cout << std::endl << std::endl;

	//(8) 
	std::cout << "Testing operator==()" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_same1("The same"), ms_same2("The same");
	if (ms_same1==ms_same2){
		std::cout << "Same success" << std::endl;
		std::cout << std::endl;
	}
	MyString ms_different("The same (NOT)");
	if (!(ms_same1==ms_different)) {
		std::cout << "Different success" << std::endl;
	}
	std::cout << std::endl << std::endl;

	//(9)
	std::cout << "Testing operator=()" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_assign("Before assignment");
	std::cout << ms_assign.c_str() << std::endl;
	std::cout << std::endl;
	ms_assign = MyString("After performing assignment");
	std::cout << ms_assign.c_str() << std::endl;
	std::cout << std::endl << std::endl;

	//(10)
	std::cout << "Testing operator+" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_append1("The first part");
	MyString ms_append2(" and the second");
	std::cout << ms_append1.c_str() <<std::endl << ms_append2.c_str() <<std::endl;
	MyString ms_concat = ms_append1+ ms_append2;
	std::cout << ms_concat.c_str() <<std::endl << std::endl << std::endl;

	//(11)
	std::cout << "Testing operator[]()" << std::endl;
	std::cout << "=====================================" << std::endl;
	MyString ms_access("Access successful (NOT)");
	ms_access[17] = 0;
	std::cout << std::endl;

	//(12)
	std::cout << "Testing operator<<()" << std::endl;
	std::cout << "=====================================" << std::endl;
	std::cout << ms_access << std::endl;
	std::cout << std::endl << std::endl;

	std::cout << "------------End of Tests------------" << std::endl;
}
