/**
 * @brief  CS-202 Project 8  proj8.cpp file
 * @Author Cicelia Siu
 *
 * This file is the .cpp file to test Project 8
 */
#include <iostream>

#include "ArrayList.h"
#include "NodeList.h"

int main(){
	DataType value1(1, 1.0);
	DataType value2(2, 2.0);
	DataType value3(3, 3.0);
	DataType value4(4, 4.0);
	DataType value5(5, 5.0);
	DataType * temp = &value1;
	Node n1(value1);
	Node n2(value2);
	Node n3(value3);
	Node n4(value4);
	Node n5(value5);
	Node * tempNode = &n1;


	std::cout << std::endl << "--------------------Node Based List-------------------------------" << std::endl;


	std::cout << std::endl << "---Testing Default(NL1), Parameterized(NL2), and Copy Ctor(NL2 to NL3)---" << std::endl;
	// Default Constructor
	NodeList nodeList1;

	// Parameterized Constructor
	NodeList nodeList2(3, value1);

	// Copy Constructor
	NodeList nodeList3(nodeList2);
	
	std::cout << "NL 1: " << std::endl << nodeList1 << std::endl
		<< "NL2: " << std::endl << nodeList2 << std::endl
		<< "NL3: " << std::endl << nodeList3 << std::endl;


	std::cout << std::endl << "---Testing = operator (NL1 = NL2)---" << std::endl;
	nodeList1 = nodeList2;
	std::cout << "NL 1: " << std::endl << nodeList1 << std::endl
		<< "NL2: " << std::endl << nodeList2 << std::endl
		<< "NL3: " << std::endl << nodeList3 << std::endl;


	std::cout << std::endl << "---Testing [] operator (NL1[1] = {2,2} and NL1[2] = {3,3})---" << std::endl;
	nodeList1[1] = value2;
	nodeList1[2] = value3;
	std::cout << "NL 1: " << std::endl << nodeList1 << std::endl;


	std::cout << std::endl << "---Testing front of NL1, back of NL1, and find in NL1---" << std::endl
		<< "NL1: " << std::endl << nodeList1 << std::endl
		<< "front: " << nodeList1.front()->data() << std::endl
		<< "back: " << nodeList1.back()->data() << std::endl;
	Node * prevNode;
	std::cout << "find {2, 2}: " << nodeList1.find(value2, prevNode)->data() << std::endl;
	std::cout << std::endl << "---Testing insertAfter and insertBefore---" << std::endl<< "(Inserting {4, 4} before {1, 1} and after {3, 3}" << std::endl;
	nodeList1.insertBefore(tempNode, value4);
	tempNode = &n3;
	nodeList1.insertAfter(tempNode, value4);
	std::cout << "NL1: " << nodeList1 << std::endl;


	std::cout << std::endl << "---Testing erase (erasing {3, 3})---" << std::endl;
	nodeList1.erase(tempNode);
	std::cout << "NL1: " << nodeList1 << std::endl;


	std::cout << std::endl << "---Testing size, empty, and clear---" << std::endl;
		std::cout<< "(clearing contents of list 3)" << std::endl;
	nodeList3.clear();
	std::cout << std::boolalpha
		<< "List 1:" << nodeList1 << std::endl
		<< "\tsize(): " << nodeList1.size() << std::endl
		<< "\tempty(): " << nodeList1.empty() << std::endl
		<< "List 2:" << nodeList2 << std::endl
		<< "\tsize(): " << nodeList2.size() << std::endl
		<< "\tempty(): " << nodeList2.empty() << std::endl
		<< "List 3:" << nodeList3 << std::endl
		<< "\tsize(): " << nodeList3.size() << std::endl
		<< "\tempty(): " << nodeList3.empty() << std::endl;


std::cout << std::endl << "-----------------------Array Based List-------------------" << std::endl;


	std::cout << std::endl << "---Testing Default (List 1), Parameterized (List 2), and Copy Ctor (List 2 to List 3)---" << std::endl;
	// Default Constructor
	ArrayList list1;

	// Parameterized Constructor
	ArrayList list2(3, value1);

	// Copy Constructor
	ArrayList list3(list2);
	
	std::cout << "List 1: " << std::endl << list1 << std::endl
		<< "List 2: " << std::endl << list2 << std::endl
		<< "List 3: " << std::endl << list3 << std::endl;


	std::cout << std::endl << "---Testing = operator (List1 = List2)---" << std::endl;
	list1 = list2;
	std::cout << "List 1: " << std::endl << list1 << std::endl
		<< "List 2: " << std::endl << list2 << std::endl
		<< "List 3: " << std::endl << list3 << std::endl;


	std::cout << std::endl << "---Testing [] operator (List1[1] = {2,2} and List1[2] = {3,3} and the same in List2)---" << std::endl;
	list1[1] = value2;
	list1[2] = value3;
	list2[1] = value2;
	list2[2] = value3;
	std::cout << "List 1: " << std::endl << list1 << std::endl
		<< "List 2: " << std::endl << list2 << std::endl
		<< "List 3: " << std::endl << list3 << std::endl;

	
	std::cout << std::endl << "---Testing front of List1, back of List 1, and find in List1---" << std::endl
		<< "List 1: " << std::endl << list1 << std::endl
		<< "front: " << *list1.front() << std::endl
		<< "back: " << *list1.back() << std::endl;
	DataType * prev;
	std::cout << "find {2, 2}: " << *list1.find(value2, prev) << std::endl;
		//<< "And previous ptr after calling find: " << *prev << std::endl;


	std::cout << std::endl << "---Testing insertAfter and/or insertBefore (Both work.Just not together, so must comment one out)---" << std::endl
	<< "(Inserting {4, 4} before {1, 1} in List 1 and after {3, 3}" << std::endl;
	//list1.insertBefore(temp, value4);
	temp = &value3;
	list1.insertAfter(temp, value4);
	std::cout << "List 1: " << std::endl << list1 << std::endl;


	std::cout << std::endl << "---Testing erase (erasing {3, 3})---" << std::endl;
	temp = &value3;	
	list1.erase(temp);
	std::cout << "List 1: " << std::endl << list1 << std::endl;



	std::cout << std::endl << "---Testing size, empty , and clear---" << std::endl
		<< "(clearing contents of list 3)" << std::endl;
	list3.clear();
	std::cout << std::boolalpha
		<< "List 1:" << std::endl << list1 << std::endl
		<< "\tsize(): " << list1.size() << std::endl
		<< "\tempty(): " << list1.empty() << std::endl
		<< "List 2:" << std::endl << list2 << std::endl
		<< "\tsize(): " << list2.size() << std::endl
		<< "\tempty(): " << list2.empty() << std::endl
		<< "List 3:" << std::endl << list3 << std::endl
		<< "\tsize(): " << list3.size() << std::endl
		<< "\tempty(): " << list3.empty() << std::endl;
	std::cout << std::endl << "------------------------END OF TESTS----------------------------" << std::endl;

	return 0;
}
