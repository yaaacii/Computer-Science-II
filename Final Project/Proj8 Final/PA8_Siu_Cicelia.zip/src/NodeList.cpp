/**
 * @brief  CS-202 Project 8 NodeList class .cpp file
 * @Author Cicelia Siu
 *
 * This file is the .cpp file to implement the NodeList class for Project 8
 */

#include "NodeList.h"

std::ostream & operator<<(std::ostream & os, const NodeList & nodeList){
    size_t count = nodeList.size();
    for (int i = 0; i < count; i++){
        os << i << ". " << nodeList [i] <<std::endl;
    }
    return os;
}


NodeList::NodeList(){
    m_head = nullptr;
}

NodeList::NodeList(size_t count, const DataType & value){
    Node * next = nullptr;
    Node * curr = nullptr;
    for (int i = 0; i < count; i++){
        if (!next){
            next = new Node(value); 
        } else {
            curr = new Node (value, next);
            next = curr;
        }
    }
    m_head = curr;
}

NodeList::NodeList(const NodeList & other){
    Node * thisCurr = nullptr;
    Node * newN = nullptr;

    for (Node * rhsCurr = other.m_head; rhsCurr!=nullptr; rhsCurr = rhsCurr->m_next){
        newN = new Node (*rhsCurr);
        if (!thisCurr){
            m_head = newN;
            thisCurr = m_head;
        } else {
            thisCurr->m_next = newN;
            thisCurr = newN;
        }
    }
}

NodeList::~NodeList(){
    for (Node * curr = m_head; curr != NULL; curr = curr->m_next){
		m_head = m_head->m_next;
		delete curr;
		curr = NULL;
		curr= m_head;	
	}
}

NodeList & NodeList::operator= (const NodeList & rhs){
    if(this != &rhs){
        m_head = rhs.m_head;
    }
	return *this;
}

Node * NodeList::front(){
    return m_head;
}

Node * NodeList::back(){
	Node * curr = m_head;
    if (m_head == NULL){
        return NULL;
    }
    for (curr = m_head; curr->m_next!= NULL; curr = curr->m_next){
    }
    return curr;
}

Node * NodeList::find(const DataType & target, Node * & previous, const Node * after){
    Node * curr = m_head;
    Node * prev = NULL;
    Node * found = NULL;

    for (Node * curr = m_head; curr!=NULL; curr = curr->m_next){
        if (curr->data()==target){
            found = curr;
            previous = prev;
            break;
        } else {
            prev = curr;
        }
    }
    return found;

}

Node * NodeList::insertAfter(Node * target, const DataType & value){
    Node * found = NULL;
    Node * newN = NULL;
	Node * temp = NULL;

    found = find (target->data(), temp, nullptr);
    
    if (found){
        if (found->m_next == NULL) {
            newN = new Node(value);
            found->m_next = newN;
        } else {
            newN = new Node (value, found->m_next);
            found-> m_next = newN;
        }
    }
	return newN;
}

Node * NodeList::insertBefore(Node * target, const DataType & value){
    Node *previous = nullptr;
    Node *found = nullptr;
    Node *newN = nullptr;

    found = find(target->data(), previous, nullptr);

    if (found != NULL) {

        if (previous == NULL) {
            newN = new Node(value, found);
            m_head = newN;
        } else {
            newN = new Node(value, found);
            previous->m_next = newN;
        }
    }

    return newN;
	return NULL;
}

Node * NodeList::erase(Node * target){
    Node *previous = NULL;
    Node *found = NULL;
    

    found = find(target->data(), previous, NULL);

        if (found != NULL){
			if (!previous){
            	m_head = m_head->m_next;
            	return m_head;
			}
			previous->m_next = found->m_next;
        }

    delete found;
    return previous->m_next;
}

DataType & NodeList::operator[] (size_t position){
    Node * curr = m_head;
    for (int i = 0; i < position ; curr = curr->m_next , i++){
        if (!curr){
            break;
        }
    }
    return  curr->data();
}
const DataType & NodeList::operator[] (size_t position) const{
    Node * curr = m_head;
    for (int i = 0; i < position ; curr = curr->m_next , i++){
        if (!curr){
            break;
        }
    }
    return  curr->data();
}

size_t NodeList::size() const{
    Node * curr = m_head;
    size_t count;
    for (count = 0; curr != nullptr ; curr = curr->m_next , count++){
    }
    return count;
}

bool NodeList::empty() const{
    if (!m_head){
        return 1;
    } else {
        return 0;
    }
}


void NodeList::clear(){
	Node * temp;
	Node * curr = m_head;
    for (int i = 0; curr!=NULL; i++){
		temp = curr;
		curr = curr->m_next;
        delete temp;
    }
	m_head = NULL;
}  
