/**
 * @brief  CS-202 Project 8 ArrayList class .cpp file
 * @Author Cicelia Siu
 *
 * This file is the .cpp file to implement the ArrayList class for Project 8
 */


#include "ArrayList.h"



ArrayList::ArrayList(){
    m_array = NULL;
    m_size = 0;
    m_maxsize = 0;
}	

ArrayList::ArrayList(size_t count, const DataType & value){
    m_array = new DataType [count];
    m_size = 0;
    m_maxsize = count;
    for(int i = 0; i < count; i++){
        m_array[i] = value;
        m_size++;
    }
}	

ArrayList::ArrayList(const ArrayList & other){
    m_array = new DataType [other.m_size];
    m_size = 0;
    for(int i = 0; i < other.m_size; i++){
        m_array[i] = other.m_array[i];
        m_size++;
    }
    m_maxsize = other.m_maxsize;

}				    	

ArrayList::~ArrayList(){
    delete [] m_array;
	m_array = NULL;
	m_size = 0;
	m_maxsize= 0;
}

ArrayList & ArrayList::operator= (const ArrayList & rhs){
    if (this != &rhs){
        try{
            delete [] m_array;
            m_array = new DataType [rhs.m_size];
            m_size = 0;
            for(int i = 0; i < rhs.m_size; i++){
                m_array[i] = rhs.m_array[i];
                m_size++;
            }
            m_maxsize = rhs.m_maxsize;
        } catch (const std::bad_alloc & error){
            std::cerr << "Assignment Failed: " << error.what() <<std::endl;
        }
        
    }
    return *this;
}

DataType * ArrayList::front(){
    for (int i = 0; i < m_size; i++){
        if (m_array[i].intVal()){
            return &m_array[i];
        }
    }
    return NULL;
}

DataType * ArrayList::back(){
    for (int i = m_size; i > 0; i--){
        if (m_array[i].intVal() && m_array[i].doubleVal()){                   
            return &m_array[i];
        }
    }
    return NULL;
}

DataType * ArrayList::find(const DataType & target, DataType * &previous, const DataType * after){
	int i = 0;	
	previous = NULL;    
	for (i = 0; i < m_size; i++){
        if (m_array[i].intVal() && m_array[i].doubleVal() &&m_array[i] == target){          //?
            if (i != 0){
                previous = &m_array[i-1];
            }                    
            return &m_array[i];
        }
    }
    return NULL;
}	

DataType * ArrayList::insertAfter (DataType * target, const DataType & value){
	int add = 0;
	int i = 0;
    DataType * before = NULL;
    DataType * item = find(*target, before, NULL);
	DataType * temp = NULL;
	DataType * newArr = new DataType[m_maxsize+1];
	
    if (item != NULL){
        resize (m_size +1);
        for (i = 0; i < m_size; i++){
			newArr[i+add] = m_array[i];
            if (m_array[i] == *target){
				add = 1;
                newArr[i+add] = value;
				temp = &newArr[i];
			}
            
        }
	
	delete [] m_array;
	m_array = newArr;
    }
	return temp;
}

DataType * ArrayList::insertBefore (DataType * target, const DataType & value){
    int add = 0;
	int i = 0;
    DataType * before = NULL;
    DataType * item = find(*target, before, NULL);
	DataType * temp = NULL;
	DataType * newArr = new DataType[m_size+1];
	

    if (item != NULL){
        resize (m_size +1);
        for (i = 0; i < m_size; i++){
            if (m_array[i] == *target){
                newArr[i] = value;
				temp = &newArr[i];
                add = 1;
			}
            newArr[i+add] = m_array[i];
        }
	
	delete [] m_array;
	m_array = newArr;
    }
    return temp;
}

DataType * ArrayList::erase(DataType * target){
    int add = 0;
	int i = 0;
    DataType * before = NULL;
    DataType * item = find(*target, before, NULL);
	DataType * curr = item;
    if (item != NULL){

        for (i = 0; curr != m_array+m_size -1; curr++){

            *curr = *(curr+1);
   
        }
		m_size--;
    }
    return item;
}

DataType & ArrayList::operator[] (size_t position){
    return m_array[position];
}

size_t ArrayList::size() const{
    return m_size;
}

bool ArrayList::empty() const{
    if (!m_array){
        return 1;
    } else {
        return 0;
    }
}

void ArrayList::clear(){
	if (m_array != NULL){
		delete [] m_array;
		m_array = NULL;
	}
	m_size = 0;
	m_maxsize = 0;
}


void ArrayList::resize(size_t count){
	int i = 0;
    m_maxsize = m_size = count;
    DataType * resizeArr = new DataType [count];
    for (i = 0 ; i < m_size; i++){
        resizeArr[i]= m_array[i];;
    }
	delete [] m_array;
	m_array = resizeArr;
	DataType d(0,0.0);
	m_array[i] = d;

}

std::ostream & operator<<(std::ostream & os, const ArrayList & arrayList){
     for (int i = 0; i < arrayList.m_size; i++){
         os << i << ". "<< arrayList.m_array[i] << std::endl;
     }                          
     return os;
}
