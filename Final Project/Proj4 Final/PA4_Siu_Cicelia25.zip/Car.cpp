/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */

#include <iostream>
#include <fstream>
#include "Car.h"

//default Constructor
Car::Car(){
    m_year = 0;
    myStringCopy(m_make, "N/A");
    myStringCopy(m_model, "N/A");
    m_baseprice = 0.0;
    m_finalprice = 0.0;
    m_available = false;
    myStringCopy(m_owner, "N/A");
    //do we put m_sensors in this one?
}

//paramaterized Constructor
Car::Car(int year, const char* make,  const char* model, float baseprice, Sensor * sensors, int sensorCount) {
    m_year = year;
    myStringCopy(m_make, make);
    myStringCopy(m_model, model);
    m_baseprice = baseprice;
    Sensor * sensorPtr = sensors;
    for (int i = 0; i < sensorCount; i++){
        *this + *sensorPtr++;
    }
}

//copy constructor
Car:: Car (const Car & other){
    m_year = other.m_year;
    myStringCopy(m_make, other.m_make);
    myStringCopy(m_model, other.m_model);
    m_baseprice = other.m_baseprice;
    m_finalprice = other.m_finalprice;
    m_available = other.m_available;
    myStringCopy( m_owner, other.m_owner);

    const Sensor * sensorInput = other.m_sensors;
    Sensor * sensorOutput = m_sensors;
    for (int j = 0; j < 3; j++){
        *sensorOutput = Sensor(*sensorInput);
        sensorOutput++;
        sensorInput++;
    }
}


//get funtions
int Car::getYear() const{
    return m_year;
}

char * Car::getMake() {
    return m_make;
}
char * Car::getModel(){
    return m_model;
}
const Sensor * Car::getSensors() {
    return m_sensors;
}
float Car::getBasePrice() const{
    return m_baseprice;
}
float Car:: getFinalPrice() const {
    return m_finalprice;
}
bool Car::getAvailable() const{
    return m_available;
}
char * Car:: getOwner(){ 
    return m_owner;
}

int Car::getSensorCount(){
    return m_sensorCount;
}

//set functions
void Car::setYear(int year){
    m_year = year;
}

void Car::setMake(char* make){
    myStringCopy(m_make, make);
}

void Car::setModel(char* model){
    myStringCopy(m_model, model);
}

void Car::setBasePrice(float baseprice){
    m_baseprice = baseprice;
}

void Car::setAvailable (bool available){
    m_available = available;
}

void Car:: setOwner(char* owner){
    myStringCopy(m_owner, owner);
}

void Car::setSensorCount(int setCount){
    m_sensorCount = setCount;
}

//etc methods

void Car::updatePrice(){
    float tempPrice = 0.0;
    tempPrice = Car::getBasePrice();

    Sensor * sensorPtr = m_sensors;
    for (int k = 0; k< 3; k++){
        tempPrice += sensorPtr->getExtraCost();
        sensorPtr++;
    }
    m_finalprice = tempPrice;
}

void Car::print() {
    std::cout << Car::getYear() << " " << Car::getMake() << " " << Car::getModel() << "\tBase: " << Car::getBasePrice() << " \tWith {"; 
    Sensor * sensorPtr = m_sensors;
    float extraCost= Car::getBasePrice();
    for (int i = 0; i<3 ;i++){
        if (!myStringCompare(sensorPtr->getType(), "none")){
            std::cout << sensorPtr->getType() << " ";
        }
        extraCost += sensorPtr->getExtraCost();
        sensorPtr++;
    }
    std::cout << "}: " << extraCost << "\tAvailable: "<< std::boolalpha << m_available;
    if (m_available == 0){
        std::cout <<  " " <<Car::getOwner();
    }
    std:: cout << std::endl;
}

void Car::estimateCost(int rentDays){
    float rental_cost = getFinalPrice() * rentDays;
    std::cout<< "The estimated cost for the " << getYear() << " "<< getMake() << " "<< getModel() << " is $" << rental_cost << " for " << rentDays<< " days."<< std::endl;

}

Car & Car::operator+(const char * owner){ //add owner
    myStringCopy(m_owner, owner);
    setAvailable(0);
    return *this;
}

    Car & Car::operator+ (const Sensor & sensor){ //add Sensor operator
    Sensor * sensorPtr = m_sensors;
    for (int i = 0; i < m_sensorCount; i++){
        sensorPtr++;
    }
    *sensorPtr = Sensor(sensor);
    updatePrice();
    
    
    return *this;
}
