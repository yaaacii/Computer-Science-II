/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */
#include <iostream>
#include <fstream>
#include "menu.h"

void readIn(Agency &agency){
    char inputfile[100];
    
    std:: cout << "Please enter an input file:" << std::endl;
    std:: cin >> inputfile;
    std::ifstream inputstream;
    inputstream.open (inputfile);
    if (!inputstream){
        std::cerr << "File does not exist" << std:: endl;
        return;
    }

    agency.readAllData(inputstream);
}

void printAll(Agency &agency){
    agency.printData();
    agency.printAllCars();
}

void printFiltered(Agency &agency){
    agency.printData();
    agency.printAvailableCars();
}

void reserveOne(Agency &agency){
    int carChoice = 0;
    char ownerName[256];

    printFiltered(agency);
    std:: cout << "Choose the car which you would like to rent:";
    std:: cin >> carChoice;
    std::cout << "You chose : ";
    agency[carChoice-1].print();
    std::cout << "What is your name? ";
    std:: cin >> ownerName;
    agency[carChoice-1] + ownerName; //overloading operator to add owner and change availablity
}

void userMenuPrompt (int &menuchoice){
    std::cout << "Car Dealership\n================\n1. Read from File \n2. Print All \n3. Print Available\n4. Reserve Car.\n5. Exit " << std:: endl;
    std:: cin >> menuchoice;
}
