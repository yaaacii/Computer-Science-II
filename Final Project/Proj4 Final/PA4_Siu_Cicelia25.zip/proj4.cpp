/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */
#include <iostream>
#include <fstream>
#include "menu.h"

int main(){
    int choice;
    Agency agency;

    do {
	userMenuPrompt(choice);
        switch (choice){
            case 1: 
                readIn(agency);
                break;
            case 2:
                printAll(agency);
                break;
            case 3:
                printFiltered(agency);
                break;
            case 4:
                reserveOne(agency);
                break;
            default:
                break;
        }

    }while (choice != 5);
    return 0;
}
