/**
 *  @Student: Siu, Cicelia
 *  @Date: February 2, 2020
 *  @Project: 2. Rental Car Dealership
 */

#include <iostream>
#include <fstream>

#include "my_string.h"

size_t myStringLength(const char*str){
    size_t length = 0;
    while (*str != '\0'){
        length++;
        str++;
    }
    return length;
}

int myStringCompare(const char * str1, const char * str2){
    while ( *str1 != '\0' || *str2 != '\0'){
        if (*str1 > *str2){
            return 1;
        }
        else if (*str1 < *str2){
            return -1;
        }
        else {
            str1++;
            str2++;
        }   
    }
    return 0;
}

char *myStringCopy(char* destination, const char* source){
    while (*source != '\0'){
        *destination++ = *source++;
    }
    *destination = '\0'; //add null to complete c-string
    return destination;
}

char *myStringCat(char* destination, const char* source){
    while (*destination != '\0'){
        destination++;
    }
    while (*source != '\0'){
        *destination = *source;
        destination++;
        source++;
    }
    *destination = '\0'; //add null to complete c-string
    return destination;
}

const char * mySubstring(char * source, int start, int end) {
    char substring[256];
    char * substring_ptr = substring;
    char * str = source;
    str += start;
    for (int i = start; i < end; i++, substring_ptr++, str++) {
        *substring_ptr = *str;
    }
    *substring_ptr = '\0';
    substring_ptr = substring;

    myStringCopy(source, substring);
    return str;
}
