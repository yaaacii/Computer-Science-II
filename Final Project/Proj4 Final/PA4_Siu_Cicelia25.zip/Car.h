/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */

#ifndef CAR_H_
#define CAR_H_
#include <iostream>
#include <fstream>
#include "Sensor.h"

class Car{
    public:
        Car(); //default
        Car(int year, const char* make, const char* model, float baseprice, Sensor *sensors, int sensorCount); //parameterized
        Car (const Car & other);   ///copy constructor

        //getters
        int getYear() const;
        char * getMake();
        char * getModel();
        const Sensor * getSensors();
        float getBasePrice () const;
        float getFinalPrice() const;
        bool getAvailable () const;
        char * getOwner();
        int getSensorCount();

        //setters
        void setYear( int year);
        void setMake( char * make);
        void setModel (char * model);
        void setBasePrice(float baseprice);
        void setAvailable (bool available);
        void setOwner(char* owner);
        void setSensorCount(int setCount);

        void updatePrice(); //same as setFinal Price
        void print(); //not done
        void estimateCost(int rentalDays); //not done
        void addSensor(); //do i need this?
        void addOwner();

        Car & operator+(const Sensor & sensor);
        Car & operator+(const char * owner);
        

    private:
        int m_year;
        char m_make [256];
        char m_model [256];
        Sensor m_sensors[3];
        int m_sensorCount;
        float m_baseprice;
        float m_finalprice;
        bool m_available;
        char m_owner[256];
};

#endif
