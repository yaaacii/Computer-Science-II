/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */
#ifndef AGENCY_H_
#define AGENCY_H_
#include <iostream>
#include <fstream>
#include "Car.h"



class Agency{
    public:
        Agency();

        //getters
        char* getName();
        int getZip();

        //setters
        void setName (char* newName); 
        void setZip(int zip);

        //etc methods
        Car & operator[](int index);
        void readAllData(std:: ifstream &inputstream);
        void printActiveSensors();
        void printData();
        void printAllCars();
        void printAvailableCars();
        

    private:
        char m_name [256];
        int m_zipcode;
        Car m_inventory [5];

};

#endif // 
