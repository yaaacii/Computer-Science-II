/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */
#ifndef MENU_H_
#define MENU_H_
#include <iostream>
#include <fstream>
#include "Agency.h"



void readIn(Agency &agency);
void printAll(Agency &agency);
void printFiltered(Agency &agency);
void reserveOne(Agency &agency);
void userMenuPrompt (int &menuchoice);

#endif 

