/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */
#include <iostream>
#include <fstream>
#include "Agency.h"

Agency::Agency(){
    myStringCopy(m_name, "N/A");
    m_zipcode = 0;
}

char * Agency::getName(){
    return m_name;
}
int Agency::getZip(){
    return m_zipcode;
}

void Agency::setName(char* newName){
    myStringCopy(m_name, newName);
}
void Agency::setZip(int zip){
    m_zipcode = zip;
}

Car & Agency::operator[](int index){
    Car * inventoryPtr = m_inventory;
    for (int i= 0; i < index; i++ ){
        inventoryPtr++;
    }
    return *inventoryPtr;
}

void Agency::readAllData(std::ifstream &inputstream){
    char name[256];
    int zipcode;
	int year;
    char make [256];
    char model [256];
    float baseprice;
    bool available;
    char owner[256];
	//char sensorName[256];
    //char * sensorPtr = sensorName;

    inputstream >> name >> zipcode;
    setName(name);
    setZip(zipcode);


    
    for (int i = 0; i< 5; i++) {
        //temporary variables for the set functions
        inputstream >> year >> make >> model >> baseprice;
        //std::cout << year << make << model << baseprice << "\n";
        (*this)[i].setYear(year);
        (*this)[i].setMake(make);
        (*this)[i].setModel(model);
        (*this)[i].setBasePrice(baseprice);
        (*this)[i].setSensorCount(0);
        
        char sensor[256];
        char * sensorPtr;

        bool loop = false;
        do {
            myStringCopy(sensor, "");
            sensorPtr = sensor;
            inputstream >> sensor;
            //only get the inside of the {}, but it only gets the last one and idk how to fix it
            // this messes up active sensors and the extra cost

            if (*sensorPtr == '{') {
                mySubstring(sensor, 1, myStringLength(sensor));
            }
            if (*(sensorPtr + myStringLength(sensor) - 1) == '}') {
                loop = true;
                mySubstring(sensor, 0, myStringLength(sensor) - 1);
            }

            if (myStringLength(sensor) > 0) {
                (*this)[i] + Sensor(sensor);
            }
            (*this)[i].setSensorCount(0);
            
        } while (!loop);

        inputstream >> available;
        (*this)[i].setAvailable(available);
        if (available == 0){
            inputstream >> owner;
            (*this)[i].setOwner(owner);
		
        }
    }
	inputstream.close();
}

void Agency::printActiveSensors(){
    std:: cout << " {gps} : ";
    std:: cout << Sensor::static_getGps_cnt(); 
    std:: cout << " {camera} : ";
    std:: cout << Sensor::static_getCamera_cnt();
    std:: cout << " {lidar } : ";
    std:: cout << Sensor::static_getLidar_cnt();
    std:: cout << " {radar} : ";
    std:: cout << Sensor::static_getRadar_cnt();
}

void Agency::printData(){
    std:: cout << getName()<< " " << getZip()<< std::endl;
    std:: cout << " Active Sensors: ";
    printActiveSensors();
	std:: cout<< std::endl;
    
}

void Agency::printAllCars(){
    for (int i = 0; i < 5; i++){
        std::cout << "["<<i+1<<"]";
        (*this)[i].print();
    }
}

void Agency::printAvailableCars(){
    Car * inventoryPtr = m_inventory;
    for (int i = 0; i < 5; i++){
        if (inventoryPtr->getAvailable() == 1){
            std::cout << "["<<i+1<<"]";
            inventoryPtr->print();
        }
        inventoryPtr++;
    }
}
