/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4. Rental Car Dealership
 */

#ifndef MY_STRING_H_
#define MY_STRING_H_
#include <iostream>
#include <fstream>

/**find the length of the string excluding the null
 * @param str pointer of the cstring needed to find the length
 * @pre cstring to find the length of
 * @post finds and returns the length of the string
 */
size_t myStringLength(const char*str);

/**compares 2 cstrings character by character in comparision on the ASCII table and swaps them if they arent in the right order
 * @param str1 cstring that gets compared to str2
 * @param str2 cstring that gets compared to str1
 * @pre input of 2 cstrings
 * @post compares strs and swaps indexes if they are not in the right order
 */
int myStringCompare(const char * str1, const char * str2);

/**copies cstring from source pointer to a destination pointer
 * @param destination is the pointer to paste the cstring
 * @param source is the pointer from where the cstring is copied
 * @pre have a source input and a destination output to copy to
 * @post copies cstring from source to destination pointer
 */
char *myStringCopy(char* destination, const char* source);

/**adds cstring from source to the end of destination, replacing the null
 * @param destination is the pointer to add the source cstring to
 * @param source is the pointer to copy the cstring from
 * @pre have a cstring in source; may or may not have cstring in destination pointer
 * @post cstring from source will be added to end of destination
 */
char *myStringCat(char* destination, const char* source);

const char * mySubstring(char * source, int start, int end);

#endif

