/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */
#include <iostream>
#include <fstream>
#include "Sensor.h"

//costs of the extra sensors
const float gpsCost = 5.00;
const float cameraCost = 10.00;
const float lidarCost = 15.00;
const float radarCost = 20.00;
const float noneCost = 0.00;



int Sensor::gps_cnt = 0;
int Sensor::camera_cnt = 0;
int Sensor::lidar_cnt = 0;
int Sensor::radar_cnt = 0;


//default
Sensor:: Sensor(){ 
    myStringCopy(m_type, "none");
    m_extracost = noneCost;
    gps_cnt = 0; //could also use resetters here
    camera_cnt = 0;
    lidar_cnt = 0;
    radar_cnt = 0;
}

//parameterized
Sensor::Sensor(char* type){
    setType(type);

}
//COPT CONSTRUCTOR
Sensor:: Sensor(const Sensor &sensor){
    myStringCopy(m_type, sensor.m_type);
    m_extracost = sensor.m_extracost;

}

Sensor & Sensor::operator=(const Sensor & rhs) {
    myStringCopy(m_type, rhs.m_type);
    m_extracost = rhs.m_extracost;


    return *this;
}

//getters
const char * Sensor::getType() const {
    return m_type;
}

float Sensor::getExtraCost() const{
    return m_extracost;
}

int Sensor::static_getGps_cnt(){
    return gps_cnt;
}

int Sensor::static_getCamera_cnt(){
    return camera_cnt;
}

int Sensor::static_getLidar_cnt(){
    return lidar_cnt;
}

int Sensor::static_getRadar_cnt(){
    return radar_cnt;
}

//setters

//set extra cost depending on the type; idk if i was supposed to get the extra cost of the full thing?
void Sensor::setExtraCost(char* type){
    if (myStringCompare(type, "gps")){
        m_extracost += gpsCost;
    } else if (myStringCompare(type, "camera")){
        m_extracost += cameraCost;
    }else if (myStringCompare(type, "lidar")){
        m_extracost += lidarCost;
    }else if (myStringCompare(type, "radar")){
        m_extracost += radarCost;
    } else {
        m_extracost += noneCost;
    }
}

//if a type is picked out, then extra cost should be calculated and type count should be added
void Sensor::setType(char* type){
    myStringCopy (m_type, type);
    setExtraCost(m_type);
    if (myStringCompare(type, "gps")){
        Sensor::gps_cnt++;
    } else if (myStringCompare(type, "camera")){
        Sensor::camera_cnt++;
    }else if (myStringCompare(type, "lidar")){
        Sensor::lidar_cnt++;
    }else if (myStringCompare(type, "radar")){
        Sensor::lidar_cnt++;
    }

}


//resetters the word static only needs to be in the definition
void Sensor::static_resetGps_cnt(){
    gps_cnt = 0;
}

void Sensor::static_resetCamera_cnt(){
    camera_cnt = 0;
}

void Sensor::static_resetLidar_cnt(){
    lidar_cnt = 0;
}

void Sensor::static_resetRadar_cnt(){
    radar_cnt = 0;
}

bool Sensor::operator== (const Sensor & other) const{
    return myStringCompare(m_type, other.m_type) == 0;

}
