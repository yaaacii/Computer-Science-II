/**
 *  @Student: Siu, Cicelia
 *  @Date: February 17, 2020
 *  @Project: 4.
 */

#ifndef SENSOR_H_
#define SENSOR_H_
#include <iostream>
#include <fstream>
#include "my_string.h"


class Sensor {
    public:
        Sensor(); //default constructor
        Sensor(char* type); //do I have to do static in a separate one? or is this fine? do i need the extracost?
        Sensor (const Sensor &sensor); //copy constructor
        Sensor & operator=(const Sensor & rhs);
        //getters
        const char* getType() const;
        float getExtraCost() const;
        //static getters
        static int static_getGps_cnt();
        static int static_getCamera_cnt();
        static int static_getLidar_cnt();
        static int static_getRadar_cnt();

        //setters
        void setType(char* type);
        void setExtraCost(char* type); //can i make this a pass by reference?
        //static resetters
        static void static_resetGps_cnt();
        static void static_resetCamera_cnt();
        static void static_resetLidar_cnt();
        static void static_resetRadar_cnt();

        //check if 2 sensor objects are the same
        bool operator==(const Sensor & other) const;
    private:
        char m_type[256];
        float m_extracost;
        static int gps_cnt;
        static int camera_cnt;
        static int lidar_cnt;
        static int radar_cnt;
};



#endif 
