
#ifndef VECTORRECURSION_HPP_
#define VECTORRECURSION_HPP_


#include <vector>

template <typename T>
void vector_resort (std::vector<T> & v, size_t start, size_t end){
    if (end == start){
        return;
    } else{
        for (size_t i = start; i < end-1; i++){
            if (v[i] > v[i+1]){
                //swap
                T temp = v[i];
                v[i] = v[i+1];
                v[i+1] = temp;
            }
        }
    }
    vector_resort(v, start, end-1);
}

template <typename T>
int vector_research (std::vector<T> & v, const T & target, int start, int end) {
     if  (start > end) {
         return -1;
    }
    int mid =  (start + end) / 2;
    if (v[mid] < target) {
        return vector_research(v, target, mid+1, end);
    } else if (v[mid] > target) {
        return vector_research(v, target, start, mid-1);
    }

    return mid;
}

#endif // !VECTORRECURSION_HPP_
