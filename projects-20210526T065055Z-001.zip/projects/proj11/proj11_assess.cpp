#include <iostream>
#include <fstream>
#include "VectorRecursion.hpp"

#include <numeric>
#include <chrono>
 
int main(){
    volatile int sink;

    for (size_t size = 100; size <= 1000000; size *= 100) {
        //size= 10000;
        // record start time
        auto start = std::chrono::high_resolution_clock::now();
        // do some work
        std::vector<int> vec;
        for (size_t i = 0; i < size; i++){
            int value = rand() % size;
            vec.push_back(value);
        }
        vector_research(vec, 212 ,0, vec.size());
        // record end time
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> different = end-start;
        std::cout << "Time to fill and research a vector of " 
                  << size << " ints : " << different.count() << " s\n";
    }

    for (size_t size = 100; size <= 10000; size *= 100) {
        //size_t size= 10000;
        // record start time
        auto start = std::chrono::high_resolution_clock::now();
        // do some work
        std::vector<int> v;
        for (size_t i = 0; i < size; i++){
            int value = rand() % size;
            v.push_back(value);
        }
        vector_resort(v, 0, v.size()); // make sure it's a side effect
        // record end time
        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> diff = end-start;
        std::cout << "Time to fill and resort a vector of " 
                  << size << " ints : " << diff.count() << " s\n";
    }

}