/**
 * @brief  CS-202 Project 7 MyString class .cpp file
 * @Author Cicelia Siu
 *
 * This file is the .cpp file to implement the MyString class for Project 7
 */


#include "MyString.h"

//ctor that creates a MyString with a m_size = 0 and m_buffer of NULL
MyString::MyString(){
    strcpy(m_buffer, "NULL");
    m_size = 0;
    std::cout<< "Default MyString Constructor" << std::endl;
}
//ctor that creates a MyString with a m_size of the length of the string parameter. 
//Then a try-catch exception handling block is used to examine the inputted c-string and allocate 
MyString::MyString(const char * str){
    std::cout << "Parameterized MyString Constructor" << std::endl;
    size_t length = strlen(str);

    try {
        buffer_allocate(length);
        strcpy(m_buffer, str);
    } 
    catch (const std::bad_alloc & error){
        std::cout << "Parameterized MyString Constructor Failed" << std::endl;
    }
}

//copy ctor creates a new MyString with the same size as the inputted MyString and with the same cstring with 
//allocation handing with a try-catch block
MyString::MyString(const MyString & other_myStr){
    std::cout << "Copy MyString Constructor" << std::endl;
    m_size = other_myStr.m_size;
    try{
        buffer_allocate(m_size);
        strcpy(m_buffer, other_myStr.m_buffer);
    }
    catch (std:: bad_alloc & error){
        std::cout << "Copy MyString Constructor Failed" << std::endl;
    }
}

//dtor: deallocates destroys m_buffer then resets it to the default NULL and sets the m_size to 0
MyString::~MyString(){
    std::cout << "MyString Destructor" << std::endl;
    buffer_deallocate();
}

size_t MyString::size() const {
    std::cout << "Returning the size of the memory" << std::endl;
    return m_size;
}

size_t MyString::length() const {
    std::cout << "Returning the length of the m_buffer" << std::endl;
    return strlen(m_buffer);
}

const char * MyString::c_str() const {
    std::cout << "Returning m_buffer as a cstring" << std::endl;
    return m_buffer;
}

bool MyString::operator== (const MyString & other_myStr) const {
    std::cout << "MyString Comparison Operator" << std::endl;
    int i = strcmp(m_buffer, other_myStr.c_str());
    if (i == 0){
        return 1;
    } else{
       return 0; 
    }
}

MyString & MyString::operator= (const MyString & other_myStr){
    std::cout << "MyString Assignment Operator" << std::endl;
    buffer_deallocate();
    buffer_allocate(other_myStr.length());
    m_size = other_myStr.size();
    strcpy(m_buffer, other_myStr.c_str());
    return *this;
}

MyString MyString::operator+ (const MyString & other_myStr) const{
    std::cout << "MyString Concatenate Operator" << std::endl;
    char string[m_size + other_myStr.size()];
    strcpy(string, m_buffer);
    strcat(string, other_myStr.c_str());
    return MyString(string);
}

char & MyString::operator[] (size_t index){
    std::cout << "MyString [] Operator" << std::endl;
    return m_buffer[index];
}

const char & MyString::operator[] (size_t index) const{
    std::cout << "MyString const[] Operator" << std::endl;
    return m_buffer[index];
}

std::ostream & operator<<(std::ostream & os, const MyString & myStr){
    os<< myStr.c_str();
    return os;
}

void MyString::buffer_deallocate(){
    std::cout << "MyString Buffer Deallocation" << std::endl;
    delete [] m_buffer;
    strcpy(m_buffer, "NULL");
    m_size = 0;
}

void MyString::buffer_allocate(size_t size){
    std::cout << "MyString Buffer Allocation" << std::endl;
    try{
        m_buffer = new char[size +1]; //include null
        m_size = size + 1;
    } catch (std::bad_alloc & error){
        std::cout<< error.what() <<std::endl;
    }
}
