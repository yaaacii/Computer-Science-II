/**
 *  @Student: Siu, Cicelia
 *  @Date: February 2, 2020
 *  @Project: 2. Rental Car Dealership
 */

#include <iostream>
#include <fstream>
#include "my_string.h"
#include "menu.h"

void readCars(RentalCar carArr[]){
    char inputfile[30];
    std:: cout << "Please enter an input file:" << std::endl;
    std:: cin >> inputfile;
    std::ifstream inputstream;
    inputstream.open (inputfile);
    if (!inputstream){
        std::cerr << "File does not exist" << std:: endl;
        return;
    }
    int i = 0;
    for ( i = 0; i < 5; i++){
        inputstream >> carArr[i].year>> carArr[i].make>> carArr[i].model >> carArr[i].price >> carArr[i].available;
    }
    inputstream.close();

}

void printCarsToTerminal(RentalCar carArr[]){
    int i = 0;
    for (i = 0; i < 5; i++){
        if (carArr[i].available){
            std::cout << "["<< i<< "] " << carArr[i].year<< " " << carArr[i].make<< " " << carArr[i].model<< ", $"<< carArr[i].price<< " per day, Available: true" << std::endl;
        } else if (!carArr[i].available){
            std::cout << "["<< i<< "] " << carArr[i].year<< " " << carArr[i].make<< " " << carArr[i].model<< ", $"<< carArr[i].price<< " per day, Available: false" << std::endl;
        }
    }
}

void printCarsToFile(RentalCar carArr[]){
    char outputfile[30];
    std::cout << "Please enter an output file: "<< std::endl;
    std:: cin >> outputfile;
    std::ofstream output;
    output.open (outputfile);
    for (int i = 0; i < 5; i++){
        output << carArr[i].year << " "<< carArr[i].make <<  " "<< carArr[i].model <<  " "<< carArr[i].price << " "<< carArr[i].available << std::endl;
    }
    output.close();
}

void sortCarsByPrice (RentalCar carArr[]){
    RentalCar temp;
    for (int i = 0; i < 5; i++){
        for (int j = 0; j < 5; j++){
            if (carArr[j].price > carArr[j+1].price){
                temp = carArr[j];
                carArr[j] = carArr[j+1];
                carArr[j+1] = temp;
            }
        }
    }
}

void rentalCarQuery(RentalCar carArr[]){
    int rentDays = 0;
    std:: cout << "How many days would you like to rent the car out for?" << std::endl;
    std:: cin >> rentDays;
    for(int i=0; i<5; i++){
        if (carArr[i].available){
            std:: cout << "["<< i<< "] "<< carArr[i].year << " " <<carArr[i].make << " "<< carArr[i].model << ", Total Cost: $"<< carArr[i].price*rentDays<< std::endl;
        }
    }
}

void rentalCarReserve(RentalCar carArr[]){
    int rentalDays = 0;
    int carInd = 0;
    printCarsToTerminal(carArr);
    std:: cout << "Which car would you like to rent (Enter the number)?"<< std::endl;
    std:: cin >> carInd;
    if (!carArr[carInd].available){
        std::cerr << "This car is not available. Please choose another car." << std:: endl;
        return;
    }
    std:: cout << "How many days are you renting the car for?"<< std::endl;
    std:: cin >> rentalDays;
    
    carArr[carInd].available = 0;
    std:: cout << "The "<< carArr[carInd].year << " " <<carArr[carInd].make << " "<< carArr[carInd].model<< " is now rented to you at a total cost of $"<< rentalDays*carArr[carInd].price << std::endl;
}

void userMenuPrompt (int &menuchoice){
    std::cout << "Car Dealership\n================\n1. Input cars from a file \n2. Show Cars in Terminal\n3. Save cars to File\n4. Sort the cars by price\n5. Rental Query: Find total cost of the rental with available cars\n6. Reserve the car.\n7. Exit " << std:: endl;
    std:: cin >> menuchoice;
}

