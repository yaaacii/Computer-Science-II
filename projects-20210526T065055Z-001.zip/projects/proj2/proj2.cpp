/**
 *  @Student: Siu, Cicelia
 *  @Date: February 2, 2020
 *  @Project: 2. Rental Car Dealership
 */
#include <iostream>
#include <fstream>
#include "my_string.h"
#include "menu.h"

int main() {
    RentalCar carArr[5];
    int menuchoice = 0;
    do {
        userMenuPrompt(menuchoice);
        switch (menuchoice){
            case 1:
                readCars (carArr);
                break;
            case 2:
                printCarsToTerminal(carArr);
                break;
            case 3:
                printCarsToFile(carArr);
                break;
            case 4:
                sortCarsByPrice(carArr);
                break;
            case 5:
                rentalCarQuery (carArr);
                break;
            case 6:
                rentalCarReserve (carArr);
                break;
            default:
                break;
        }
    } while (menuchoice != 7);
    return 0;
}
