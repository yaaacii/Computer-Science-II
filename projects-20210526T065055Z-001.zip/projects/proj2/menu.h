/**
 *  @Student: Siu, Cicelia
 *  @Date: February 2, 2020
 *  @Project: 2. Rental Car Dealership
 */


#ifndef MENU_H_
#define MENU_H_
#include <iostream>
#include <fstream>

struct RentalCar{
    int year;
    char make [10];
    char model [10];
    float price;
    bool available;
};

/**read information of the cars and put into an array of structs
 * @param carArr the struct array in which the cars information will be held
 * @pre must have a file with information of the cars
 * @post will have the information from the file put into an array of structs
 */
void readCars(RentalCar carArr[]);

/**will read the array of car structs and will output its information to the terminal
 * @param carArr the struct array in which the cars information will be held
 * @pre must have the array of car structs filled by reading cars from a file
 * @post will show information to the terminal
 */
void printCarsToTerminal(RentalCar carArr[]);

/**will copy information from array of car structs into a file
 * @param carArr the struct array in which the cars information will be held
 * @pre must have array of car structs filled with information
 * @post given a outputfile, the information of the cars will be printed into the file
 */
void printCarsToFile(RentalCar carArr[]);

/**sorting the array of structs by price using bubble sort
 * @param carArr the struct array in which the cars information will be held
 * @pre must have array of car structs filled with information
 * @post the array of structs will now be sorted by price
 */
void sortCarsByPrice (RentalCar carArr[]);

/**given the amount of days, the function will find the total cost of the rent for the cars that are available
 * @param carArr the struct array in which the cars information will be held
 * @pre must have array of car structs filled with information 
 * @pre a user input of how many days the car will be rented out
 * @post will print to the terminal the total cost to rent the car for the cars that are available
 */
void rentalCarQuery(RentalCar carArr[]);

/**will reserve the car for the user given which car and for how many days
 * @param carArr the struct array in which the cars information will be held
 * @pre must have array of car structs filled with information
 * @pre must know how many days to rent and the index of the car
 * @post will set the cars availability to false
 * @post will show the terminal that the car has been rented out to the user and the total cost
 */
void rentalCarReserve(RentalCar carArr[]);

/**asks the user to ender a menu choice to execute the menu
 * @param menuchoice a pass by reference for menu choice to change the menu choice variable to the user input
 * @pre user should put in a number for the menu at which user wants to do
 * @post will change the parameter's menuchoice variable to the int of which the user inputted
 */
void userMenuPrompt (int &menuchoice);

#endif
